#!/bin/bash
# Gera o instalador do Festa e Cia (Linux ou macOS).
# Pré-requisitos: JDK 17+ com jpackage (vem junto do JDK) e Maven.
set -e

echo "1/2 - Compilando o projeto e juntando as dependências (JavaFX, MySQL, JasperReports)..."
mvn clean package

echo "2/2 - Gerando o instalador com jpackage..."
rm -rf instalador
jpackage \
  --input target \
  --name "Festa e Cia" \
  --main-jar festa-e-cia-completo.jar \
  --main-class br.com.festaecia.Launcher \
  --type app-image \
  --app-version 1.0.0 \
  --vendor "Festa e Cia" \
  --dest instalador

echo
echo "Pronto! A pasta do programa está em: instalador/Festa e Cia"
echo "Para distribuir, copie essa pasta inteira (ela já inclui o Java, não precisa instalar nada a mais)."
echo
echo "Se preferir um instalador de verdade (.deb no Linux ou .dmg no macOS) em vez de uma pasta,"
echo "troque --type app-image por --type deb (Linux, precisa do pacote dpkg-dev) ou --type dmg (macOS)."
