package br.com.festaecia.util;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

/**
 * Caixas de diálogo padronizadas do sistema, com texto grande e claro.
 * Todas as telas devem usar esta classe para dar retorno ao usuário.
 */
public final class Mensagens {

    private Mensagens() {
    }

    /**
     * Informa que uma operação foi concluída com sucesso.
     *
     * @param texto mensagem exibida
     */
    public static void sucesso(String texto) {
        exibir(AlertType.INFORMATION, "Tudo certo", texto);
    }

    /**
     * Mostra uma informação ao usuário.
     *
     * @param titulo título da janela
     * @param texto  mensagem exibida
     */
    public static void informacao(String titulo, String texto) {
        exibir(AlertType.INFORMATION, titulo, texto);
    }

    /**
     * Mostra uma mensagem de erro ou de dado inválido.
     *
     * @param texto mensagem exibida
     */
    public static void erro(String texto) {
        exibir(AlertType.ERROR, "Atenção", texto);
    }

    /**
     * Pergunta ao usuário se deseja continuar (usar antes de excluir).
     *
     * @param texto pergunta, por exemplo "Deseja realmente excluir?"
     * @return {@code true} se o usuário confirmou
     */
    public static boolean confirmar(String texto) {
        Alert alerta = criar(AlertType.CONFIRMATION, "Confirmação", texto);
        ButtonType sim = new ButtonType("Sim");
        ButtonType nao = new ButtonType("Não");
        alerta.getButtonTypes().setAll(sim, nao);
        return alerta.showAndWait().filter(b -> b == sim).isPresent();
    }

    private static void exibir(AlertType tipo, String titulo, String texto) {
        criar(tipo, titulo, texto).showAndWait();
    }

    private static Alert criar(AlertType tipo, String titulo, String texto) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.getDialogPane().getStylesheets().add(Navegador.getEstilo());
        alerta.getDialogPane().setMinWidth(480);
        return alerta;
    }
}
