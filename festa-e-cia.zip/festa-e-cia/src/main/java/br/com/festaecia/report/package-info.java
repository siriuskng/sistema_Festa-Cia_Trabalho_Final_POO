/**
 * Geração dos relatórios com JasperReports.
 */
package br.com.festaecia.report;
