package br.com.festaecia.service;

import br.com.festaecia.dao.ItemDAO;
import br.com.festaecia.model.Item;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Regras de negócio do inventário: validação dos dados e controle de
 * quantidade disponível ao cadastrar ou alterar itens.
 */
public class ItemService {

    private static final List<String> CATEGORIAS_PADRAO =
            List.of("Cadeiras", "Mesas", "Toalhas", "Decoração", "Louças", "Som e iluminação");
    private static final BigDecimal VALOR_MAXIMO = new BigDecimal("99999999.99");

    private final ItemDAO dao = new ItemDAO();

    /**
     * Lista todos os itens do inventário.
     *
     * @return itens em ordem alfabética
     * @throws RegraNegocioException se o banco não responder
     */
    public List<Item> listar() throws RegraNegocioException {
        try {
            return dao.listarTodos();
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Categorias sugeridas: as padrão mais as já usadas nos itens.
     *
     * @return categorias sem repetição
     * @throws RegraNegocioException se o banco não responder
     */
    public List<String> listarCategorias() throws RegraNegocioException {
        try {
            Set<String> categorias = new LinkedHashSet<>(CATEGORIAS_PADRAO);
            categorias.addAll(dao.listarCategorias());
            return List.copyOf(categorias);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Cadastra um item novo (id 0) ou altera um existente.
     * <p>
     * Em item novo, o disponível começa igual ao total. Em alteração, a
     * quantidade alugada é preservada: disponível = novo total - alugados.
     *
     * @param item dados do formulário
     * @throws RegraNegocioException se os dados forem inválidos ou o banco falhar
     */
    public void salvar(Item item) throws RegraNegocioException {
        validar(item);
        try {
            if (item.getId() == 0) {
                item.setQuantidadeDisponivel(item.getQuantidadeTotal());
                dao.inserir(item);
            } else {
                Item atual = dao.buscarPorId(item.getId());
                if (atual == null) {
                    throw new RegraNegocioException("Este item não existe mais. Atualize a lista.");
                }
                int alugados = atual.getQuantidadeAlugada();
                if (item.getQuantidadeTotal() < alugados) {
                    throw new RegraNegocioException("Há " + alugados + " unidades alugadas no momento. "
                            + "A quantidade total não pode ser menor que isso.");
                }
                item.setQuantidadeDisponivel(item.getQuantidadeTotal() - alugados);
                dao.atualizar(item);
            }
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Exclui um item, desde que nunca tenha sido usado em pedidos.
     *
     * @param id identificador do item
     * @throws RegraNegocioException se o item já estiver em pedidos ou o banco falhar
     */
    public void excluir(int id) throws RegraNegocioException {
        try {
            if (dao.estaEmPedidos(id)) {
                throw new RegraNegocioException("Este item já foi usado em pedidos e não pode ser excluído. "
                        + "Para tirá-lo de uso, altere a quantidade total para 0.");
            }
            dao.excluir(id);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    private void validar(Item item) throws RegraNegocioException {
        if (item.getNome() == null || item.getNome().isBlank()) {
            throw new RegraNegocioException("Informe o nome do item.");
        }
        if (item.getNome().length() > 100) {
            throw new RegraNegocioException("O nome do item deve ter no máximo 100 letras.");
        }
        if (item.getDescricao() != null && item.getDescricao().length() > 200) {
            throw new RegraNegocioException("A descrição deve ter no máximo 200 letras.");
        }
        if (item.getCategoria() == null || item.getCategoria().isBlank()) {
            throw new RegraNegocioException("Informe a categoria do item.");
        }
        if (item.getCategoria().length() > 50) {
            throw new RegraNegocioException("A categoria deve ter no máximo 50 letras.");
        }
        if (item.getQuantidadeTotal() < 0) {
            throw new RegraNegocioException("A quantidade total não pode ser negativa.");
        }
        BigDecimal valor = item.getValorDiaria();
        if (valor == null || valor.signum() < 0) {
            throw new RegraNegocioException("Informe um valor de diária igual ou maior que zero.");
        }
        valor = valor.setScale(2, RoundingMode.HALF_UP);
        if (valor.compareTo(VALOR_MAXIMO) > 0) {
            throw new RegraNegocioException("O valor da diária informado é alto demais.");
        }
        item.setValorDiaria(valor);
    }

    private RegraNegocioException erroBanco(SQLException e) {
        return new RegraNegocioException(
                "Não foi possível acessar o banco de dados. Verifique se o MySQL está ligado.", e);
    }
}
