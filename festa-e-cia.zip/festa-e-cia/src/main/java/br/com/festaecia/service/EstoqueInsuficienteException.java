package br.com.festaecia.service;

/**
 * Lançada quando um pedido pede mais unidades de um item do que o
 * estoque tem disponível no momento.
 * <p>
 * É uma exceção não verificada porque ocorre no meio de uma operação de
 * banco de dados (dentro de {@code PedidoDAO}); quem deve tratá-la é a
 * camada de serviço, convertendo-a em {@link RegraNegocioException} com
 * uma mensagem pronta para o usuário.
 */
public class EstoqueInsuficienteException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String nomeItem;
    private final int quantidadeDisponivel;

    /**
     * Cria a exceção.
     *
     * @param nomeItem             nome do item sem estoque suficiente
     * @param quantidadeDisponivel quantidade que ainda está disponível
     */
    public EstoqueInsuficienteException(String nomeItem, int quantidadeDisponivel) {
        super("Estoque insuficiente de " + nomeItem + ": restam apenas " + quantidadeDisponivel + ".");
        this.nomeItem = nomeItem;
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    public String getNomeItem() {
        return nomeItem;
    }

    public int getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }
}
