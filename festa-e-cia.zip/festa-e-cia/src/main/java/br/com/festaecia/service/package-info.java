/**
 * Regras de negócio, como a validação e a baixa de estoque.
 */
package br.com.festaecia.service;
