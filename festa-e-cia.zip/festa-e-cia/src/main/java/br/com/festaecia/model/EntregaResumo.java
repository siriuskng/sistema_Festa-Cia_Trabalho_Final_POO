package br.com.festaecia.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Linha de resultado da consulta de entregas no período: dados do pedido
 * e do cliente já combinados, com um resumo textual dos itens, pronta
 * para ser exibida em tela ou impressa em relatório.
 *
 * @param idPedido        identificador do pedido
 * @param clienteNome     nome do cliente
 * @param clienteTelefone telefone do cliente
 * @param dataEntrega     data combinada de entrega
 * @param dataDevolucao   data combinada de devolução
 * @param enderecoEntrega endereço onde os itens devem ser entregues
 * @param status          situação atual do pedido
 * @param itensResumo     texto com os itens e quantidades, por exemplo "10x Cadeira, 5x Mesa"
 * @param valorTotal      valor total do pedido
 */
public record EntregaResumo(
        int idPedido,
        String clienteNome,
        String clienteTelefone,
        LocalDate dataEntrega,
        LocalDate dataDevolucao,
        String enderecoEntrega,
        StatusPedido status,
        String itensResumo,
        BigDecimal valorTotal) {
}
