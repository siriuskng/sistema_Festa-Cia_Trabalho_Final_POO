package br.com.festaecia.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Fábrica de conexões com o banco MySQL.
 * <p>
 * Lê a configuração do arquivo {@code db.properties}. Se existir um arquivo
 * com esse nome na pasta de execução, ele é usado; caso contrário, vale o
 * arquivo embutido no sistema (pasta resources).
 */
public final class ConexaoBD {

    private static final String ARQUIVO = "db.properties";
    private static Properties config;

    private ConexaoBD() {
    }

    /**
     * Abre uma nova conexão com o banco. Quem chama é responsável por
     * fechá-la (use try-with-resources).
     *
     * @return conexão aberta
     * @throws SQLException se não for possível conectar
     */
    public static Connection getConexao() throws SQLException {
        Properties p = configuracao();
        return DriverManager.getConnection(
                p.getProperty("db.url"),
                p.getProperty("db.usuario"),
                p.getProperty("db.senha", ""));
    }

    /**
     * Testa se o banco está acessível.
     *
     * @return {@code true} se a conexão foi aberta com sucesso
     */
    public static boolean testar() {
        try (Connection c = getConexao()) {
            return c.isValid(3);
        } catch (SQLException | IllegalStateException e) {
            return false;
        }
    }

    private static synchronized Properties configuracao() {
        if (config == null) {
            Properties p = new Properties();
            try {
                Path externo = Path.of(ARQUIVO);
                if (Files.exists(externo)) {
                    try (Reader r = Files.newBufferedReader(externo, StandardCharsets.UTF_8)) {
                        p.load(r);
                    }
                } else {
                    try (InputStream in = ConexaoBD.class.getResourceAsStream("/" + ARQUIVO)) {
                        if (in == null) {
                            throw new IllegalStateException("Arquivo " + ARQUIVO + " não encontrado.");
                        }
                        p.load(new InputStreamReader(in, StandardCharsets.UTF_8));
                    }
                }
            } catch (IOException e) {
                throw new IllegalStateException("Não foi possível ler " + ARQUIVO, e);
            }
            config = p;
        }
        return config;
    }
}
