package br.com.festaecia.service;

import br.com.festaecia.dao.PedidoDAO;
import br.com.festaecia.model.ItemPedido;
import br.com.festaecia.model.Pedido;
import br.com.festaecia.model.StatusPedido;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Regras de negócio dos pedidos de locação: validação dos dados, cálculo
 * do valor total, controle de estoque (feito em transação pelo
 * {@link PedidoDAO}) e das mudanças de status.
 */
public class PedidoService {

    private final PedidoDAO dao = new PedidoDAO();

    /**
     * Lista pedidos para a tela de listagem.
     *
     * @param filtroTexto  texto buscado no nome do cliente; vazio ou
     *                     {@code null} não filtra
     * @param filtroStatus status para filtrar; {@code null} lista todos
     * @return pedidos encontrados
     * @throws RegraNegocioException se o banco não responder
     */
    public List<Pedido> listar(String filtroTexto, StatusPedido filtroStatus) throws RegraNegocioException {
        try {
            return dao.listarResumo(filtroTexto, filtroStatus);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Busca um pedido com os itens carregados.
     *
     * @param id identificador do pedido
     * @return o pedido, ou {@code null} se não existir
     * @throws RegraNegocioException se o banco não responder
     */
    public Pedido buscarComItens(int id) throws RegraNegocioException {
        try {
            return dao.buscarComItens(id);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Registra um novo pedido: valida os dados, calcula o valor total e
     * dá baixa no estoque dos itens, tudo em uma única transação.
     *
     * @param pedido pedido com cliente, datas, endereço e itens preenchidos
     * @throws RegraNegocioException se os dados forem inválidos, não houver
     *                               estoque suficiente ou o banco falhar
     */
    public void registrar(Pedido pedido) throws RegraNegocioException {
        validar(pedido);
        pedido.setDataPedido(LocalDate.now());
        pedido.setStatus(StatusPedido.AGENDADO);
        pedido.setValorTotal(pedido.calcularTotal());
        try {
            dao.inserir(pedido);
        } catch (EstoqueInsuficienteException e) {
            throw new RegraNegocioException(e.getMessage());
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Muda o status de um pedido, seguindo o fluxo permitido: de
     * {@code AGENDADO} para {@code ENTREGUE} ou {@code CANCELADO}, e de
     * {@code ENTREGUE} para {@code DEVOLVIDO}. Ao cancelar ou devolver, os
     * itens voltam automaticamente ao estoque.
     *
     * @param idPedido identificador do pedido
     * @param novo     novo status desejado
     * @throws RegraNegocioException se a mudança não for permitida ou o banco falhar
     */
    public void mudarStatus(int idPedido, StatusPedido novo) throws RegraNegocioException {
        Pedido atual = buscarComItens(idPedido);
        if (atual == null) {
            throw new RegraNegocioException("Este pedido não existe mais. Atualize a lista.");
        }
        boolean permitido = (atual.getStatus() == StatusPedido.AGENDADO
                && (novo == StatusPedido.ENTREGUE || novo == StatusPedido.CANCELADO))
                || (atual.getStatus() == StatusPedido.ENTREGUE && novo == StatusPedido.DEVOLVIDO);
        if (!permitido) {
            throw new RegraNegocioException(
                    "Não é possível mudar o pedido de \"" + atual.getStatus() + "\" para \"" + novo + "\".");
        }
        try {
            dao.atualizarStatus(idPedido, novo);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Exclui um pedido, desde que ainda esteja {@link StatusPedido#AGENDADO},
     * devolvendo os itens ao estoque.
     *
     * @param idPedido identificador do pedido
     * @throws RegraNegocioException se o pedido já tiver sido entregue, ou se o banco falhar
     */
    public void excluir(int idPedido) throws RegraNegocioException {
        Pedido atual = buscarComItens(idPedido);
        if (atual == null) {
            throw new RegraNegocioException("Este pedido não existe mais. Atualize a lista.");
        }
        if (atual.getStatus() != StatusPedido.AGENDADO) {
            throw new RegraNegocioException("Somente pedidos agendados podem ser excluídos. "
                    + "Pedidos entregues devem ser devolvidos; para cancelar um pedido entregue, "
                    + "não é mais possível, pois os itens já foram usados.");
        }
        try {
            dao.excluirDevolvendoEstoque(idPedido);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    private void validar(Pedido pedido) throws RegraNegocioException {
        if (pedido.getCliente() == null) {
            throw new RegraNegocioException("Selecione o cliente do pedido.");
        }
        if (pedido.getEnderecoEntrega() == null || pedido.getEnderecoEntrega().isBlank()) {
            throw new RegraNegocioException("Informe o endereço de entrega.");
        }
        if (pedido.getEnderecoEntrega().length() > 200) {
            throw new RegraNegocioException("O endereço de entrega deve ter no máximo 200 letras.");
        }
        if (pedido.getDataEntrega() == null || pedido.getDataDevolucao() == null) {
            throw new RegraNegocioException("Informe as datas de entrega e de devolução.");
        }
        if (pedido.getDataDevolucao().isBefore(pedido.getDataEntrega())) {
            throw new RegraNegocioException("A data de devolução não pode ser antes da data de entrega.");
        }
        if (pedido.getItens().isEmpty()) {
            throw new RegraNegocioException("Adicione ao menos um item ao pedido.");
        }
        Set<Integer> idsUsados = new HashSet<>();
        for (ItemPedido ip : pedido.getItens()) {
            if (ip.getQuantidade() <= 0) {
                throw new RegraNegocioException("A quantidade de \"" + ip.getItem().getNome()
                        + "\" deve ser maior que zero.");
            }
            if (!idsUsados.add(ip.getItem().getId())) {
                throw new RegraNegocioException("O item \"" + ip.getItem().getNome()
                        + "\" foi adicionado mais de uma vez. Junte as quantidades em um só lançamento.");
            }
        }
    }

    private RegraNegocioException erroBanco(SQLException e) {
        return new RegraNegocioException(
                "Não foi possível acessar o banco de dados. Verifique se o MySQL está ligado.", e);
    }
}
