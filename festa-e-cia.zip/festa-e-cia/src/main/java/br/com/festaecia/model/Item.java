package br.com.festaecia.model;

import java.math.BigDecimal;

/**
 * Item do inventário disponível para locação (mesa, cadeira, toalha etc.).
 * <p>
 * Guarda a quantidade total que a loja possui e a quantidade disponível
 * agora (total menos o que está alugado).
 */
public class Item {

    private int id;
    private String nome;
    private String descricao;
    private String categoria;
    private int quantidadeTotal;
    private int quantidadeDisponivel;
    private BigDecimal valorDiaria;

    /** Cria um item vazio (usado ao ler do banco ou do formulário). */
    public Item() {
    }

    /**
     * Cria um item completo.
     *
     * @param id                   identificador (0 se ainda não foi gravado)
     * @param nome                 nome do item
     * @param descricao            descrição opcional
     * @param categoria            categoria do item
     * @param quantidadeTotal      quantidade total no inventário
     * @param quantidadeDisponivel quantidade livre para alugar
     * @param valorDiaria          valor da diária por unidade
     */
    public Item(int id, String nome, String descricao, String categoria,
                int quantidadeTotal, int quantidadeDisponivel, BigDecimal valorDiaria) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.categoria = categoria;
        this.quantidadeTotal = quantidadeTotal;
        this.quantidadeDisponivel = quantidadeDisponivel;
        this.valorDiaria = valorDiaria;
    }

    /**
     * Verifica se há unidades suficientes para alugar.
     *
     * @param quantidade quantidade desejada
     * @return {@code true} se a quantidade disponível cobre o pedido
     */
    public boolean temDisponivel(int quantidade) {
        return quantidade > 0 && quantidadeDisponivel >= quantidade;
    }

    /**
     * Dá baixa no estoque (item alugado).
     *
     * @param quantidade quantidade que saiu
     * @throws IllegalArgumentException se não houver unidades suficientes
     */
    public void baixar(int quantidade) {
        if (!temDisponivel(quantidade)) {
            throw new IllegalArgumentException("Estoque insuficiente de " + nome
                    + ": restam apenas " + quantidadeDisponivel + ".");
        }
        quantidadeDisponivel -= quantidade;
    }

    /**
     * Devolve unidades ao estoque (item devolvido ou pedido cancelado).
     *
     * @param quantidade quantidade que voltou
     */
    public void devolver(int quantidade) {
        quantidadeDisponivel = Math.min(quantidadeTotal, quantidadeDisponivel + quantidade);
    }

    /**
     * Quantidade que está alugada no momento.
     *
     * @return total menos disponível
     */
    public int getQuantidadeAlugada() {
        return quantidadeTotal - quantidadeDisponivel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getQuantidadeTotal() {
        return quantidadeTotal;
    }

    public void setQuantidadeTotal(int quantidadeTotal) {
        this.quantidadeTotal = quantidadeTotal;
    }

    public int getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }

    public void setQuantidadeDisponivel(int quantidadeDisponivel) {
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    public BigDecimal getValorDiaria() {
        return valorDiaria;
    }

    public void setValorDiaria(BigDecimal valorDiaria) {
        this.valorDiaria = valorDiaria;
    }

    /**
     * Texto usado em listas de seleção.
     *
     * @return o nome do item
     */
    @Override
    public String toString() {
        return nome;
    }
}
