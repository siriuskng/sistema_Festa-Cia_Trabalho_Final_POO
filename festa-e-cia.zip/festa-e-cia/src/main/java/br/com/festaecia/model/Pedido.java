package br.com.festaecia.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Pedido de locação feito por um {@link Cliente}, com um ou mais
 * {@link ItemPedido}.
 */
public class Pedido {

    private int id;
    private Cliente cliente;
    private LocalDate dataPedido;
    private LocalDate dataEntrega;
    private LocalDate dataDevolucao;
    private String enderecoEntrega;
    private BigDecimal valorTotal = BigDecimal.ZERO;
    private StatusPedido status = StatusPedido.AGENDADO;
    private final List<ItemPedido> itens = new ArrayList<>();

    /**
     * Número de dias de locação (mínimo de 1), usado no cálculo do total.
     *
     * @return dias entre a entrega e a devolução, nunca menor que 1
     */
    public long getDias() {
        long dias = ChronoUnit.DAYS.between(dataEntrega, dataDevolucao);
        return Math.max(1, dias);
    }

    /**
     * Calcula o valor total do pedido: soma dos subtotais dos itens,
     * multiplicada pelos dias de locação.
     *
     * @return valor total do pedido
     */
    public BigDecimal calcularTotal() {
        BigDecimal somaItens = itens.stream()
                .map(ItemPedido::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return somaItens.multiply(BigDecimal.valueOf(getDias()));
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public LocalDate getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(LocalDate dataPedido) {
        this.dataPedido = dataPedido;
    }

    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(LocalDate dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public String getEnderecoEntrega() {
        return enderecoEntrega;
    }

    public void setEnderecoEntrega(String enderecoEntrega) {
        this.enderecoEntrega = enderecoEntrega;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public StatusPedido getStatus() {
        return status;
    }

    public void setStatus(StatusPedido status) {
        this.status = status;
    }

    /**
     * Itens deste pedido. A lista retornada é a lista interna: use
     * {@link #adicionarItem(Item, int, BigDecimal)} para incluir itens.
     *
     * @return itens do pedido
     */
    public List<ItemPedido> getItens() {
        return itens;
    }

    /**
     * Adiciona um item ao pedido.
     *
     * @param item          item locado
     * @param quantidade    quantidade locada
     * @param valorUnitario valor da diária combinado
     */
    public void adicionarItem(Item item, int quantidade, BigDecimal valorUnitario) {
        itens.add(new ItemPedido(0, item, quantidade, valorUnitario));
    }
}
