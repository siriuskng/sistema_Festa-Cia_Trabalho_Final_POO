package br.com.festaecia.controller;

import br.com.festaecia.model.EntregaResumo;
import br.com.festaecia.model.ItemMaisAlugado;
import br.com.festaecia.report.ReportService;
import br.com.festaecia.service.ConsultaService;
import br.com.festaecia.service.RegraNegocioException;
import br.com.festaecia.util.FormatoData;
import br.com.festaecia.util.Mensagens;
import br.com.festaecia.util.Navegador;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * Controlador da tela de consultas: entregas de um período e o ranking
 * de itens mais alugados no mesmo período, combinando dados de pedido,
 * cliente e item. A partir dos mesmos resultados, também gera os
 * relatórios em PDF (JasperReports).
 */
public class ConsultaController {

    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    private final ConsultaService service = new ConsultaService();
    private final ReportService reportService = new ReportService();

    /** Último resultado buscado, reaproveitado para gerar os relatórios sem consultar o banco de novo. */
    private List<EntregaResumo> entregasAtuais = List.of();
    private List<ItemMaisAlugado> itensAtuais = List.of();

    @FXML private DatePicker dpInicio;
    @FXML private DatePicker dpFim;
    @FXML private Label lblResultadoEntregas;
    @FXML private Label lblResultadoItens;

    @FXML private TableView<EntregaResumo> tabelaEntregas;
    @FXML private TableColumn<EntregaResumo, Number> colEntregaNumero;
    @FXML private TableColumn<EntregaResumo, String> colEntregaCliente;
    @FXML private TableColumn<EntregaResumo, String> colEntregaTelefone;
    @FXML private TableColumn<EntregaResumo, String> colEntregaData;
    @FXML private TableColumn<EntregaResumo, String> colEntregaDevolucao;
    @FXML private TableColumn<EntregaResumo, String> colEntregaStatus;
    @FXML private TableColumn<EntregaResumo, String> colEntregaItens;
    @FXML private TableColumn<EntregaResumo, String> colEntregaTotal;

    @FXML private TableView<ItemMaisAlugado> tabelaItens;
    @FXML private TableColumn<ItemMaisAlugado, String> colItemNome;
    @FXML private TableColumn<ItemMaisAlugado, String> colItemCategoria;
    @FXML private TableColumn<ItemMaisAlugado, Number> colItemQuantidade;
    @FXML private TableColumn<ItemMaisAlugado, Number> colItemPedidos;

    /** Executado pelo JavaFX ao carregar a tela. */
    @FXML
    private void initialize() {
        FormatoData.aplicarEm(dpInicio);
        FormatoData.aplicarEm(dpFim);

        colEntregaNumero.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().idPedido()));
        colEntregaCliente.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().clienteNome()));
        colEntregaTelefone.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().clienteTelefone()));
        colEntregaData.setCellValueFactory(c -> new ReadOnlyStringWrapper(FormatoData.formatar(c.getValue().dataEntrega())));
        colEntregaDevolucao.setCellValueFactory(c -> new ReadOnlyStringWrapper(FormatoData.formatar(c.getValue().dataDevolucao())));
        colEntregaStatus.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().status().toString()));
        colEntregaItens.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().itensResumo()));
        colEntregaTotal.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarMoeda(c.getValue().valorTotal())));
        tabelaEntregas.setPlaceholder(new Label("Nenhuma entrega encontrada no período."));

        colItemNome.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().nomeItem()));
        colItemCategoria.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().categoria()));
        colItemQuantidade.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().quantidadeAlugada()));
        colItemPedidos.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().numeroPedidos()));
        tabelaItens.setPlaceholder(new Label("Nenhum item locado no período."));

        LocalDate hoje = LocalDate.now();
        dpInicio.setValue(hoje);
        dpFim.setValue(hoje.plusDays(7));
        buscar();
    }

    @FXML
    private void buscar() {
        LocalDate inicio = dpInicio.getValue();
        LocalDate fim = dpFim.getValue();
        try {
            entregasAtuais = service.entregasNoPeriodo(inicio, fim);
            tabelaEntregas.setItems(FXCollections.observableArrayList(entregasAtuais));
            lblResultadoEntregas.setText(entregasAtuais.size() + (entregasAtuais.size() == 1
                    ? " entrega encontrada no período." : " entregas encontradas no período."));

            itensAtuais = service.itensMaisAlugados(inicio, fim);
            tabelaItens.setItems(FXCollections.observableArrayList(itensAtuais));
            lblResultadoItens.setText(itensAtuais.isEmpty() ? "Nenhum item locado no período."
                    : itensAtuais.size() + (itensAtuais.size() == 1 ? " item locado no período." : " itens locados no período."));
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void gerarPdfEntregas() {
        if (entregasAtuais.isEmpty()) {
            Mensagens.erro("Não há entregas no período para colocar no relatório.");
            return;
        }
        try {
            File pdf = reportService.gerarAgendaDeEntregas(entregasAtuais, dpInicio.getValue(), dpFim.getValue());
            Mensagens.sucesso("Relatório gerado em: " + pdf.getAbsolutePath());
            abrirArquivo(pdf);
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void gerarPdfItens() {
        if (itensAtuais.isEmpty()) {
            Mensagens.erro("Não há itens locados no período para colocar no relatório.");
            return;
        }
        try {
            File pdf = reportService.gerarItensMaisAlugados(itensAtuais, dpInicio.getValue(), dpFim.getValue());
            Mensagens.sucesso("Relatório gerado em: " + pdf.getAbsolutePath());
            abrirArquivo(pdf);
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    /**
     * Abre o PDF gerado no leitor padrão do computador, quando o sistema
     * operacional permitir. Se não for possível abrir automaticamente, o
     * usuário já sabe onde encontrar o arquivo pela mensagem de sucesso.
     *
     * @param arquivo arquivo PDF recém-gerado
     */
    private void abrirArquivo(File arquivo) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(arquivo);
            }
        } catch (IOException e) {
            // Sem problema: o arquivo já foi salvo, só não foi possível abrir automaticamente.
        }
    }

    @FXML
    private void voltar() {
        Navegador.irPara("menu-principal.fxml", "Festa e Cia");
    }

    private String formatarMoeda(BigDecimal valor) {
        return String.format(BR, "R$ %.2f", valor);
    }
}
