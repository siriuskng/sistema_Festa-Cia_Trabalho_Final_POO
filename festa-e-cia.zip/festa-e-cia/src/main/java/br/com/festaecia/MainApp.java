package br.com.festaecia;

import br.com.festaecia.util.Navegador;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Aplicação JavaFX do sistema Festa e Cia.
 * Configura a janela principal e abre o menu inicial.
 */
public class MainApp extends Application {

    /**
     * Chamado pelo JavaFX ao iniciar a aplicação.
     *
     * @param palco janela principal fornecida pelo JavaFX
     */
    @Override
    public void start(Stage palco) {
        Navegador.inicializar(palco);
        palco.setMaximized(true);
        Navegador.irPara("menu-principal.fxml", "Festa e Cia");
        palco.show();
    }

    /**
     * Inicia o ciclo de vida do JavaFX.
     *
     * @param args argumentos da linha de comando
     */
    public static void main(String[] args) {
        launch(args);
    }
}
