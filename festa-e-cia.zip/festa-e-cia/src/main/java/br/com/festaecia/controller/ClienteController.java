package br.com.festaecia.controller;

import br.com.festaecia.model.Cliente;
import br.com.festaecia.service.ClienteService;
import br.com.festaecia.service.RegraNegocioException;
import br.com.festaecia.util.Mensagens;
import br.com.festaecia.util.Navegador;
import java.util.Locale;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * Controlador da tela de clientes: lista, busca, cadastra, altera e
 * exclui clientes em uma única tela.
 */
public class ClienteController {

    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    private final ClienteService service = new ClienteService();
    private final ObservableList<Cliente> clientes = FXCollections.observableArrayList();
    private FilteredList<Cliente> filtrados;
    /** Cliente selecionado para alteração; {@code null} quando é um cadastro novo. */
    private Cliente emEdicao;

    @FXML private TextField txtBusca;
    @FXML private TextField txtNome;
    @FXML private TextField txtTelefone;
    @FXML private TextField txtEndereco;
    @FXML private TextArea txtObservacoes;
    @FXML private Label lblModo;
    @FXML private Button btnExcluir;
    @FXML private TableView<Cliente> tabela;
    @FXML private TableColumn<Cliente, String> colNome;
    @FXML private TableColumn<Cliente, String> colTelefone;
    @FXML private TableColumn<Cliente, String> colEndereco;

    /** Executado pelo JavaFX ao carregar a tela. */
    @FXML
    private void initialize() {
        colNome.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getNome()));
        colTelefone.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getTelefone()));
        colEndereco.setCellValueFactory(c -> new ReadOnlyStringWrapper(
                c.getValue().getEndereco() == null ? "" : c.getValue().getEndereco()));

        filtrados = new FilteredList<>(clientes, c -> true);
        SortedList<Cliente> ordenados = new SortedList<>(filtrados);
        ordenados.comparatorProperty().bind(tabela.comparatorProperty());
        tabela.setItems(ordenados);
        tabela.setPlaceholder(new Label("Nenhum cliente encontrado."));

        txtBusca.textProperty().addListener((obs, antigo, novo) -> filtrar(novo));
        tabela.getSelectionModel().selectedItemProperty().addListener((obs, antigo, selecionado) -> {
            if (selecionado != null) {
                editar(selecionado);
            }
        });

        carregar();
        novo();
    }

    @FXML
    private void novo() {
        emEdicao = null;
        tabela.getSelectionModel().clearSelection();
        txtNome.clear();
        txtTelefone.clear();
        txtEndereco.clear();
        txtObservacoes.clear();
        lblModo.setText("Novo cliente");
        btnExcluir.setDisable(true);
        txtNome.requestFocus();
    }

    @FXML
    private void salvar() {
        Cliente cliente = lerFormulario();
        try {
            service.salvar(cliente);
            Mensagens.sucesso("Cliente salvo com sucesso.");
            carregar();
            novo();
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void excluir() {
        if (emEdicao == null) {
            return;
        }
        if (!Mensagens.confirmar("Deseja realmente excluir o cliente \"" + emEdicao.getNome() + "\"?")) {
            return;
        }
        try {
            service.excluir(emEdicao.getId());
            Mensagens.sucesso("Cliente excluído com sucesso.");
            carregar();
            novo();
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void voltar() {
        Navegador.irPara("menu-principal.fxml", "Festa e Cia");
    }

    private void editar(Cliente cliente) {
        emEdicao = cliente;
        txtNome.setText(cliente.getNome());
        txtTelefone.setText(cliente.getTelefone());
        txtEndereco.setText(cliente.getEndereco() == null ? "" : cliente.getEndereco());
        txtObservacoes.setText(cliente.getObservacoes() == null ? "" : cliente.getObservacoes());
        lblModo.setText("Alterar cliente");
        btnExcluir.setDisable(false);
    }

    private void carregar() {
        try {
            clientes.setAll(service.listar());
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    private void filtrar(String texto) {
        String busca = texto == null ? "" : texto.trim().toLowerCase(BR);
        filtrados.setPredicate(c -> busca.isEmpty()
                || c.getNome().toLowerCase(BR).contains(busca)
                || c.getTelefone().toLowerCase(BR).contains(busca));
    }

    private Cliente lerFormulario() {
        Cliente cliente = new Cliente();
        cliente.setId(emEdicao == null ? 0 : emEdicao.getId());
        cliente.setNome(txtNome.getText().trim());
        cliente.setTelefone(txtTelefone.getText().trim());
        cliente.setEndereco(txtEndereco.getText().trim());
        cliente.setObservacoes(txtObservacoes.getText().trim());
        return cliente;
    }
}
