package br.com.festaecia.controller;

import br.com.festaecia.util.ConexaoBD;
import br.com.festaecia.util.Mensagens;
import br.com.festaecia.util.Navegador;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 * Controlador do menu principal. Mostra os botões de acesso às áreas do
 * sistema e o estado da conexão com o banco de dados.
 */
public class MenuPrincipalController {

    @FXML
    private Label lblStatusBanco;

    /**
     * Executado pelo JavaFX ao carregar a tela. Testa o banco em segundo
     * plano para não travar a janela.
     */
    @FXML
    private void initialize() {
        lblStatusBanco.setText("Verificando o banco de dados...");
        Thread teste = new Thread(() -> {
            boolean ok = ConexaoBD.testar();
            Platform.runLater(() -> {
                lblStatusBanco.getStyleClass().removeAll("status-ok", "status-erro");
                if (ok) {
                    lblStatusBanco.setText("Banco de dados conectado");
                    lblStatusBanco.getStyleClass().add("status-ok");
                } else {
                    lblStatusBanco.setText("Sem conexão com o banco de dados");
                    lblStatusBanco.getStyleClass().add("status-erro");
                }
            });
        });
        teste.setDaemon(true);
        teste.start();
    }

    @FXML
    private void abrirClientes() {
        Navegador.irPara("clientes.fxml", "Festa e Cia - Clientes");
    }

    @FXML
    private void abrirEstoque() {
        Navegador.irPara("itens.fxml", "Festa e Cia - Estoque");
    }

    @FXML
    private void abrirPedidos() {
        Navegador.irPara("pedidos.fxml", "Festa e Cia - Pedidos");
    }

    @FXML
    private void abrirRelatorios() {
        Navegador.irPara("consultas.fxml", "Festa e Cia - Consultas e Relatórios");
    }

    @FXML
    private void sair() {
        Platform.exit();
    }

    private void emConstrucao(String area) {
        Mensagens.informacao(area, "A tela de " + area + " será criada nas próximas fases.");
    }
}
