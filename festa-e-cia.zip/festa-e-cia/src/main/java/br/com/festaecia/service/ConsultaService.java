package br.com.festaecia.service;

import br.com.festaecia.dao.ConsultaDAO;
import br.com.festaecia.model.EntregaResumo;
import br.com.festaecia.model.ItemMaisAlugado;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Regras de negócio das consultas personalizadas: validação do período
 * informado antes de consultar o banco.
 */
public class ConsultaService {

    private final ConsultaDAO dao = new ConsultaDAO();

    /**
     * Lista as entregas do período informado.
     *
     * @param inicio data inicial do período
     * @param fim    data final do período
     * @return entregas do período
     * @throws RegraNegocioException se as datas forem inválidas ou o banco falhar
     */
    public List<EntregaResumo> entregasNoPeriodo(LocalDate inicio, LocalDate fim) throws RegraNegocioException {
        validarPeriodo(inicio, fim);
        try {
            return dao.listarEntregasNoPeriodo(inicio, fim);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Lista os itens mais alugados no período informado.
     *
     * @param inicio data inicial do período
     * @param fim    data final do período
     * @return itens mais alugados, do mais locado para o menos locado
     * @throws RegraNegocioException se as datas forem inválidas ou o banco falhar
     */
    public List<ItemMaisAlugado> itensMaisAlugados(LocalDate inicio, LocalDate fim) throws RegraNegocioException {
        validarPeriodo(inicio, fim);
        try {
            return dao.listarItensMaisAlugados(inicio, fim);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    private void validarPeriodo(LocalDate inicio, LocalDate fim) throws RegraNegocioException {
        if (inicio == null || fim == null) {
            throw new RegraNegocioException("Informe as duas datas do período.");
        }
        if (fim.isBefore(inicio)) {
            throw new RegraNegocioException("A data final não pode ser antes da data inicial.");
        }
    }

    private RegraNegocioException erroBanco(SQLException e) {
        return new RegraNegocioException(
                "Não foi possível acessar o banco de dados. Verifique se o MySQL está ligado.", e);
    }
}
