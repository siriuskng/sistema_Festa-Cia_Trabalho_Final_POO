package br.com.festaecia.report;

import br.com.festaecia.model.EntregaResumo;
import br.com.festaecia.model.ItemMaisAlugado;
import br.com.festaecia.service.RegraNegocioException;
import br.com.festaecia.util.FormatoData;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * Geração dos relatórios do sistema em PDF, usando o JasperReports.
 * <p>
 * Cada relatório é alimentado pelos dados já trazidos por uma consulta
 * personalizada (veja {@link br.com.festaecia.service.ConsultaService}), e
 * não executa nenhum SQL por conta própria: a mesma lista de resultados que
 * aparece na tela de consultas é a que vira o PDF.
 * <p>
 * Os modelos (arquivos {@code .jrxml}) ficam em
 * {@code src/main/resources/br/com/festaecia/report} e são compilados em
 * memória na primeira vez que são usados; as vezes seguintes reaproveitam o
 * relatório já compilado, guardado em {@link #CACHE}.
 */
public class ReportService {

    private static final String PASTA_TEMPLATES = "/br/com/festaecia/report/";
    private static final String PASTA_SAIDA = "relatorios";
    private static final DateTimeFormatter ARQUIVO_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    private static final Map<String, JasperReport> CACHE = new ConcurrentHashMap<>();

    /**
     * Gera o PDF da agenda de entregas, a partir do mesmo resultado exibido
     * na tela de consultas.
     *
     * @param entregas entregas do período (já consultadas)
     * @param inicio   início do período, usado só para o texto do cabeçalho
     * @param fim      fim do período, usado só para o texto do cabeçalho
     * @return arquivo PDF gerado
     * @throws RegraNegocioException se não for possível compilar, preencher
     *                               ou salvar o relatório
     */
    public File gerarAgendaDeEntregas(List<EntregaResumo> entregas, LocalDate inicio, LocalDate fim)
            throws RegraNegocioException {
        List<LinhaEntrega> linhas = entregas.stream()
                .map(e -> new LinhaEntrega(
                        e.idPedido(),
                        e.clienteNome(),
                        e.clienteTelefone(),
                        FormatoData.formatar(e.dataEntrega()),
                        FormatoData.formatar(e.dataDevolucao()),
                        e.status().toString(),
                        e.itensResumo(),
                        formatarMoeda(e.valorTotal())))
                .toList();

        Map<String, Object> parametros = new HashMap<>();
        parametros.put("periodo", FormatoData.formatar(inicio) + " a " + FormatoData.formatar(fim));
        parametros.put("dataGeracao", DATA_HORA.format(java.time.LocalDateTime.now()));

        return gerar("agenda_entregas", parametros, linhas, "agenda_entregas");
    }

    /**
     * Gera o PDF dos itens mais alugados, a partir do mesmo resultado
     * exibido na tela de consultas.
     *
     * @param itens  itens mais alugados do período (já consultados)
     * @param inicio início do período, usado só para o texto do cabeçalho
     * @param fim    fim do período, usado só para o texto do cabeçalho
     * @return arquivo PDF gerado
     * @throws RegraNegocioException se não for possível compilar, preencher
     *                               ou salvar o relatório
     */
    public File gerarItensMaisAlugados(List<ItemMaisAlugado> itens, LocalDate inicio, LocalDate fim)
            throws RegraNegocioException {
        List<LinhaItemMaisAlugado> linhas = itens.stream()
                .map(i -> new LinhaItemMaisAlugado(i.nomeItem(), i.categoria(), i.quantidadeAlugada(), i.numeroPedidos()))
                .toList();

        Map<String, Object> parametros = new HashMap<>();
        parametros.put("periodo", FormatoData.formatar(inicio) + " a " + FormatoData.formatar(fim));
        parametros.put("dataGeracao", DATA_HORA.format(java.time.LocalDateTime.now()));

        return gerar("itens_mais_alugados", parametros, linhas, "itens_mais_alugados");
    }

    private File gerar(String nomeTemplate, Map<String, Object> parametros, List<?> linhas, String prefixoArquivo)
            throws RegraNegocioException {
        try {
            JasperReport relatorio = compilado(nomeTemplate);
            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(linhas);
            JasperPrint impresso = JasperFillManager.fillReport(relatorio, parametros, dataSource);

            Path pasta = Path.of(PASTA_SAIDA);
            Files.createDirectories(pasta);
            String nomeArquivo = prefixoArquivo + "_" + ARQUIVO_TIMESTAMP.format(java.time.LocalDateTime.now()) + ".pdf";
            Path destino = pasta.resolve(nomeArquivo);

            JasperExportManager.exportReportToPdfFile(impresso, destino.toString());
            return destino.toFile();
        } catch (JRException | IOException e) {
            throw new RegraNegocioException("Não foi possível gerar o relatório: " + e.getMessage(), e);
        }
    }

    private JasperReport compilado(String nomeTemplate) throws JRException, RegraNegocioException {
        JasperReport emCache = CACHE.get(nomeTemplate);
        if (emCache != null) {
            return emCache;
        }
        String caminho = PASTA_TEMPLATES + nomeTemplate + ".jrxml";
        try (InputStream in = ReportService.class.getResourceAsStream(caminho)) {
            if (in == null) {
                throw new RegraNegocioException("Modelo de relatório não encontrado: " + caminho);
            }
            JasperReport relatorio = JasperCompileManager.compileReport(in);
            CACHE.put(nomeTemplate, relatorio);
            return relatorio;
        } catch (IOException e) {
            throw new RegraNegocioException("Não foi possível ler o modelo de relatório: " + caminho, e);
        }
    }

    private String formatarMoeda(BigDecimal valor) {
        return String.format(BR, "R$ %.2f", valor);
    }
}
