package br.com.festaecia.service;

/**
 * Erro de regra de negócio ou de acesso ao banco, com mensagem já pronta
 * para ser mostrada ao usuário.
 */
public class RegraNegocioException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * Cria a exceção com a mensagem para o usuário.
     *
     * @param mensagem texto claro, sem termos técnicos
     */
    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }

    /**
     * Cria a exceção guardando a causa original.
     *
     * @param mensagem texto claro, sem termos técnicos
     * @param causa    erro original
     */
    public RegraNegocioException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
