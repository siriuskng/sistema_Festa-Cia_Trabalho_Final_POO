package br.com.festaecia;

/**
 * Ponto de entrada do sistema.
 * <p>
 * Esta classe existe separada da {@link MainApp} porque, em projetos JavaFX
 * sem módulos, iniciar diretamente uma classe que estende {@code Application}
 * causa o erro "JavaFX runtime components are missing" ao gerar o pacote
 * executável. Por isso o sistema deve ser iniciado por aqui.
 */
public class Launcher {

    /**
     * Inicia o sistema.
     *
     * @param args argumentos da linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
