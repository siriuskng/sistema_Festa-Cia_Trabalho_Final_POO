package br.com.festaecia.model;

/**
 * Situação de um pedido de locação.
 * <p>
 * Fluxo normal: {@link #AGENDADO} → {@link #ENTREGUE} → {@link #DEVOLVIDO}.
 * Um pedido ainda {@link #AGENDADO} também pode ser {@link #CANCELADO}.
 * {@link #DEVOLVIDO} e {@link #CANCELADO} são situações finais.
 */
public enum StatusPedido {

    AGENDADO("Agendado"),
    ENTREGUE("Entregue"),
    DEVOLVIDO("Devolvido"),
    CANCELADO("Cancelado");

    private final String rotulo;

    StatusPedido(String rotulo) {
        this.rotulo = rotulo;
    }

    /**
     * Verifica se os itens deste status já voltaram (ou nunca saíram do)
     * estoque, ou seja, se o pedido está em uma situação final.
     *
     * @return {@code true} para {@link #DEVOLVIDO} ou {@link #CANCELADO}
     */
    public boolean isFinal() {
        return this == DEVOLVIDO || this == CANCELADO;
    }

    /**
     * Texto exibido nas telas.
     *
     * @return o rótulo em português
     */
    @Override
    public String toString() {
        return rotulo;
    }
}
