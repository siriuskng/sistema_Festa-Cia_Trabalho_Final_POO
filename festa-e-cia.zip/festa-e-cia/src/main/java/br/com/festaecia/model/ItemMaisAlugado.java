package br.com.festaecia.model;

/**
 * Linha de resultado da consulta de itens mais alugados em um período:
 * quanto de cada item foi locado, somando todos os pedidos do período.
 *
 * @param nomeItem          nome do item
 * @param categoria         categoria do item
 * @param quantidadeAlugada soma das quantidades locadas nos pedidos do período
 * @param numeroPedidos     quantidade de pedidos distintos que usaram o item
 */
public record ItemMaisAlugado(String nomeItem, String categoria, int quantidadeAlugada, int numeroPedidos) {
}
