package br.com.festaecia.report;

/**
 * Uma linha do relatório "Itens mais alugados". Existe separada do
 * {@link br.com.festaecia.model.ItemMaisAlugado} porque o JasperReports lê
 * os dados por meio de métodos {@code getXxx()} (padrão JavaBean).
 */
public class LinhaItemMaisAlugado {

    private final String nomeItem;
    private final String categoria;
    private final int quantidadeAlugada;
    private final int numeroPedidos;

    /**
     * Cria uma linha do relatório.
     *
     * @param nomeItem          nome do item
     * @param categoria         categoria do item
     * @param quantidadeAlugada total de unidades locadas no período
     * @param numeroPedidos     quantidade de pedidos distintos que usaram o item
     */
    public LinhaItemMaisAlugado(String nomeItem, String categoria, int quantidadeAlugada, int numeroPedidos) {
        this.nomeItem = nomeItem;
        this.categoria = categoria;
        this.quantidadeAlugada = quantidadeAlugada;
        this.numeroPedidos = numeroPedidos;
    }

    public String getNomeItem() {
        return nomeItem;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getQuantidadeAlugada() {
        return quantidadeAlugada;
    }

    public int getNumeroPedidos() {
        return numeroPedidos;
    }
}
