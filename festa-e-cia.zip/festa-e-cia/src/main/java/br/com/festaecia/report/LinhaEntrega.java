package br.com.festaecia.report;

/**
 * Uma linha do relatório "Agenda de entregas". Existe separada do
 * {@link br.com.festaecia.model.EntregaResumo} porque o JasperReports lê os
 * dados por meio de métodos {@code getXxx()} (padrão JavaBean), e os campos
 * de data e de valor já chegam formatados como texto, prontos para impressão.
 */
public class LinhaEntrega {

    private final int idPedido;
    private final String clienteNome;
    private final String clienteTelefone;
    private final String dataEntrega;
    private final String dataDevolucao;
    private final String status;
    private final String itensResumo;
    private final String valorTotal;

    /**
     * Cria uma linha do relatório.
     *
     * @param idPedido        número do pedido
     * @param clienteNome     nome do cliente
     * @param clienteTelefone telefone do cliente
     * @param dataEntrega     data de entrega, já formatada (dd/mm/aaaa)
     * @param dataDevolucao   data de devolução, já formatada (dd/mm/aaaa)
     * @param status          situação do pedido
     * @param itensResumo     itens do pedido, resumidos em texto
     * @param valorTotal      valor total do pedido, já formatado (R$ 0,00)
     */
    public LinhaEntrega(int idPedido, String clienteNome, String clienteTelefone, String dataEntrega,
                         String dataDevolucao, String status, String itensResumo, String valorTotal) {
        this.idPedido = idPedido;
        this.clienteNome = clienteNome;
        this.clienteTelefone = clienteTelefone;
        this.dataEntrega = dataEntrega;
        this.dataDevolucao = dataDevolucao;
        this.status = status;
        this.itensResumo = itensResumo;
        this.valorTotal = valorTotal;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public String getClienteNome() {
        return clienteNome;
    }

    public String getClienteTelefone() {
        return clienteTelefone;
    }

    public String getDataEntrega() {
        return dataEntrega;
    }

    public String getDataDevolucao() {
        return dataDevolucao;
    }

    public String getStatus() {
        return status;
    }

    public String getItensResumo() {
        return itensResumo;
    }

    public String getValorTotal() {
        return valorTotal;
    }
}
