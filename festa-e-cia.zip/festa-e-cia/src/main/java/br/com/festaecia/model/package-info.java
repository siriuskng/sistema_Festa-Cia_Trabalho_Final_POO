/**
 * Classes de domínio (Cliente, Item, Pedido, ItemPedido e StatusPedido).
 */
package br.com.festaecia.model;
