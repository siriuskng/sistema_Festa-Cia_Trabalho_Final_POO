package br.com.festaecia.dao;

import br.com.festaecia.model.Item;
import br.com.festaecia.util.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 * Acesso à tabela {@code item}. Contém apenas comandos SQL; as regras de
 * negócio ficam em {@link br.com.festaecia.service.ItemService}.
 */
public class ItemDAO {

    /**
     * Grava um novo item e preenche o id gerado pelo banco.
     *
     * @param item item a gravar
     * @throws SQLException em caso de erro no banco
     */
    public void inserir(Item item) throws SQLException {
        String sql = "INSERT INTO item (nome, descricao, categoria, quantidade_total, "
                + "quantidade_disponivel, valor_diaria) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preencher(ps, item);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    item.setId(rs.getInt(1));
                }
            }
        }
    }

    /**
     * Atualiza um item existente.
     *
     * @param item item com os novos dados (o id deve estar preenchido)
     * @throws SQLException em caso de erro no banco
     */
    public void atualizar(Item item) throws SQLException {
        String sql = "UPDATE item SET nome = ?, descricao = ?, categoria = ?, quantidade_total = ?, "
                + "quantidade_disponivel = ?, valor_diaria = ? WHERE id_item = ?";
        try (Connection c = ConexaoBD.getConexao(); PreparedStatement ps = c.prepareStatement(sql)) {
            preencher(ps, item);
            ps.setInt(7, item.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Exclui um item.
     *
     * @param id identificador do item
     * @throws SQLException em caso de erro no banco
     */
    public void excluir(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement("DELETE FROM item WHERE id_item = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /**
     * Busca um item pelo id.
     *
     * @param id identificador do item
     * @return o item, ou {@code null} se não existir
     * @throws SQLException em caso de erro no banco
     */
    public Item buscarPorId(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM item WHERE id_item = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    /**
     * Lista todos os itens em ordem alfabética.
     *
     * @return lista de itens
     * @throws SQLException em caso de erro no banco
     */
    public List<Item> listarTodos() throws SQLException {
        List<Item> itens = new ArrayList<>();
        try (Connection c = ConexaoBD.getConexao();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM item ORDER BY nome")) {
            while (rs.next()) {
                itens.add(mapear(rs));
            }
        }
        return itens;
    }

    /**
     * Lista as categorias já usadas nos itens cadastrados.
     *
     * @return categorias sem repetição, em ordem alfabética
     * @throws SQLException em caso de erro no banco
     */
    public List<String> listarCategorias() throws SQLException {
        List<String> categorias = new ArrayList<>();
        try (Connection c = ConexaoBD.getConexao();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT DISTINCT categoria FROM item ORDER BY categoria")) {
            while (rs.next()) {
                categorias.add(rs.getString(1));
            }
        }
        return categorias;
    }

    /**
     * Informa se o item já foi usado em algum pedido.
     *
     * @param id identificador do item
     * @return {@code true} se existe ao menos um pedido com o item
     * @throws SQLException em caso de erro no banco
     */
    public boolean estaEmPedidos(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM item_pedido WHERE id_item = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    private void preencher(PreparedStatement ps, Item item) throws SQLException {
        ps.setString(1, item.getNome());
        if (item.getDescricao() == null || item.getDescricao().isBlank()) {
            ps.setNull(2, Types.VARCHAR);
        } else {
            ps.setString(2, item.getDescricao());
        }
        ps.setString(3, item.getCategoria());
        ps.setInt(4, item.getQuantidadeTotal());
        ps.setInt(5, item.getQuantidadeDisponivel());
        ps.setBigDecimal(6, item.getValorDiaria());
    }

    private Item mapear(ResultSet rs) throws SQLException {
        return new Item(
                rs.getInt("id_item"),
                rs.getString("nome"),
                rs.getString("descricao"),
                rs.getString("categoria"),
                rs.getInt("quantidade_total"),
                rs.getInt("quantidade_disponivel"),
                rs.getBigDecimal("valor_diaria"));
    }
}
