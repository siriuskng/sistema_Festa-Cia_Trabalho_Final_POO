package br.com.festaecia.service;

import br.com.festaecia.dao.ClienteDAO;
import br.com.festaecia.model.Cliente;
import java.sql.SQLException;
import java.util.List;

/**
 * Regras de negócio do cadastro de clientes: validação dos dados e
 * proteção de clientes que já possuem pedidos.
 */
public class ClienteService {

    private final ClienteDAO dao = new ClienteDAO();

    /**
     * Lista todos os clientes cadastrados.
     *
     * @return clientes em ordem alfabética
     * @throws RegraNegocioException se o banco não responder
     */
    public List<Cliente> listar() throws RegraNegocioException {
        try {
            return dao.listarTodos();
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Cadastra um cliente novo (id 0) ou altera um existente.
     *
     * @param cliente dados do formulário
     * @throws RegraNegocioException se os dados forem inválidos ou o banco falhar
     */
    public void salvar(Cliente cliente) throws RegraNegocioException {
        validar(cliente);
        try {
            if (cliente.getId() == 0) {
                dao.inserir(cliente);
            } else {
                dao.atualizar(cliente);
            }
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    /**
     * Exclui um cliente, desde que ele nunca tenha feito um pedido.
     *
     * @param id identificador do cliente
     * @throws RegraNegocioException se o cliente já tiver pedidos ou o banco falhar
     */
    public void excluir(int id) throws RegraNegocioException {
        try {
            if (dao.possuiPedidos(id)) {
                throw new RegraNegocioException(
                        "Este cliente já possui pedidos registrados e não pode ser excluído.");
            }
            dao.excluir(id);
        } catch (SQLException e) {
            throw erroBanco(e);
        }
    }

    private void validar(Cliente cliente) throws RegraNegocioException {
        if (cliente.getNome() == null || cliente.getNome().isBlank()) {
            throw new RegraNegocioException("Informe o nome do cliente.");
        }
        if (cliente.getNome().length() > 100) {
            throw new RegraNegocioException("O nome deve ter no máximo 100 letras.");
        }
        if (cliente.getTelefone() == null || cliente.getTelefone().isBlank()) {
            throw new RegraNegocioException("Informe o telefone do cliente.");
        }
        if (cliente.getTelefone().length() > 20) {
            throw new RegraNegocioException("O telefone deve ter no máximo 20 caracteres.");
        }
        if (cliente.getEndereco() != null && cliente.getEndereco().length() > 200) {
            throw new RegraNegocioException("O endereço deve ter no máximo 200 letras.");
        }
    }

    private RegraNegocioException erroBanco(SQLException e) {
        return new RegraNegocioException(
                "Não foi possível acessar o banco de dados. Verifique se o MySQL está ligado.", e);
    }
}
