package br.com.festaecia.dao;

import br.com.festaecia.model.Cliente;
import br.com.festaecia.util.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 * Acesso à tabela {@code cliente}. Contém apenas comandos SQL; as regras de
 * negócio ficam em {@link br.com.festaecia.service.ClienteService}.
 */
public class ClienteDAO {

    /**
     * Grava um novo cliente e preenche o id gerado pelo banco.
     *
     * @param cliente cliente a gravar
     * @throws SQLException em caso de erro no banco
     */
    public void inserir(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO cliente (nome, telefone, endereco, observacoes) VALUES (?, ?, ?, ?)";
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preencher(ps, cliente);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    cliente.setId(rs.getInt(1));
                }
            }
        }
    }

    /**
     * Atualiza um cliente existente.
     *
     * @param cliente cliente com os novos dados (o id deve estar preenchido)
     * @throws SQLException em caso de erro no banco
     */
    public void atualizar(Cliente cliente) throws SQLException {
        String sql = "UPDATE cliente SET nome = ?, telefone = ?, endereco = ?, observacoes = ? "
                + "WHERE id_cliente = ?";
        try (Connection c = ConexaoBD.getConexao(); PreparedStatement ps = c.prepareStatement(sql)) {
            preencher(ps, cliente);
            ps.setInt(5, cliente.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Exclui um cliente.
     *
     * @param id identificador do cliente
     * @throws SQLException em caso de erro no banco
     */
    public void excluir(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement("DELETE FROM cliente WHERE id_cliente = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /**
     * Busca um cliente pelo id.
     *
     * @param id identificador do cliente
     * @return o cliente, ou {@code null} se não existir
     * @throws SQLException em caso de erro no banco
     */
    public Cliente buscarPorId(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM cliente WHERE id_cliente = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    /**
     * Lista todos os clientes em ordem alfabética.
     *
     * @return lista de clientes
     * @throws SQLException em caso de erro no banco
     */
    public List<Cliente> listarTodos() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        try (Connection c = ConexaoBD.getConexao();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM cliente ORDER BY nome")) {
            while (rs.next()) {
                clientes.add(mapear(rs));
            }
        }
        return clientes;
    }

    /**
     * Informa se o cliente já possui algum pedido.
     *
     * @param id identificador do cliente
     * @return {@code true} se existe ao menos um pedido do cliente
     * @throws SQLException em caso de erro no banco
     */
    public boolean possuiPedidos(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM pedido WHERE id_cliente = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    private void preencher(PreparedStatement ps, Cliente cliente) throws SQLException {
        ps.setString(1, cliente.getNome());
        ps.setString(2, cliente.getTelefone());
        setTextoOuNulo(ps, 3, cliente.getEndereco());
        setTextoOuNulo(ps, 4, cliente.getObservacoes());
    }

    private void setTextoOuNulo(PreparedStatement ps, int indice, String valor) throws SQLException {
        if (valor == null || valor.isBlank()) {
            ps.setNull(indice, Types.VARCHAR);
        } else {
            ps.setString(indice, valor);
        }
    }

    private Cliente mapear(ResultSet rs) throws SQLException {
        return new Cliente(
                rs.getInt("id_cliente"),
                rs.getString("nome"),
                rs.getString("telefone"),
                rs.getString("endereco"),
                rs.getString("observacoes"));
    }
}
