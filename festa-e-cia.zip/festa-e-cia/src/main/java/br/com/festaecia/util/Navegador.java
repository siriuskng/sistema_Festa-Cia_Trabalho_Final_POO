package br.com.festaecia.util;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Controla a navegação entre telas. Mantém uma única janela e troca o
 * conteúdo dela, de forma que a navegação seja previsível para o usuário.
 */
public final class Navegador {

    private static final String PASTA_VIEW = "/br/com/festaecia/view/";
    private static final String CSS = "/br/com/festaecia/css/tema.css";

    private static Stage palco;
    private static Scene cena;

    private Navegador() {
    }

    /**
     * Registra a janela principal. Deve ser chamado uma vez, ao iniciar.
     *
     * @param janela janela principal do JavaFX
     */
    public static void inicializar(Stage janela) {
        palco = janela;
        palco.setMinWidth(900);
        palco.setMinHeight(650);
    }

    /**
     * Troca a tela exibida.
     *
     * @param arquivoFxml nome do arquivo FXML dentro da pasta view
     * @param titulo      título da janela
     */
    public static void irPara(String arquivoFxml, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(Navegador.class.getResource(PASTA_VIEW + arquivoFxml));
            Parent raiz = loader.load();
            if (cena == null) {
                cena = new Scene(raiz, 1000, 700);
                cena.getStylesheets().add(getEstilo());
                palco.setScene(cena);
            } else {
                cena.setRoot(raiz);
            }
            palco.setTitle(titulo);
        } catch (IOException e) {
            Mensagens.erro("Não foi possível abrir a tela: " + e.getMessage());
        }
    }

    /**
     * Endereço da folha de estilo (tema de alto contraste) do sistema.
     *
     * @return caminho do CSS pronto para uso no JavaFX
     */
    public static String getEstilo() {
        return Navegador.class.getResource(CSS).toExternalForm();
    }
}
