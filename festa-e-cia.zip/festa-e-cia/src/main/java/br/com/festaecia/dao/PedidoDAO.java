package br.com.festaecia.dao;

import br.com.festaecia.model.Cliente;
import br.com.festaecia.model.Item;
import br.com.festaecia.model.ItemPedido;
import br.com.festaecia.model.Pedido;
import br.com.festaecia.model.StatusPedido;
import br.com.festaecia.service.EstoqueInsuficienteException;
import br.com.festaecia.util.ConexaoBD;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Acesso às tabelas {@code pedido} e {@code item_pedido}.
 * <p>
 * As operações que afetam o estoque ({@link #inserir}, {@link #atualizarStatus}
 * e {@link #excluirDevolvendoEstoque}) rodam em uma única transação JDBC:
 * ou todas as alterações são gravadas, ou nenhuma é, para o estoque nunca
 * ficar inconsistente com os pedidos. A verificação de estoque usa
 * {@code SELECT ... FOR UPDATE}, que bloqueia a linha do item até o fim
 * da transação, evitando que dois pedidos simultâneos aprovem a mesma
 * unidade.
 */
public class PedidoDAO {

    /**
     * Grava um novo pedido e dá baixa no estoque dos itens, em uma única
     * transação.
     *
     * @param pedido pedido com cliente, datas e itens já preenchidos
     * @throws EstoqueInsuficienteException se algum item não tiver estoque suficiente
     * @throws SQLException                 em caso de erro no banco
     */
    public void inserir(Pedido pedido) throws SQLException {
        try (Connection c = ConexaoBD.getConexao()) {
            c.setAutoCommit(false);
            try {
                for (ItemPedido ip : pedido.getItens()) {
                    baixarEstoque(c, ip.getItem().getId(), ip.getQuantidade());
                }

                String sqlPedido = "INSERT INTO pedido (id_cliente, data_pedido, data_entrega, "
                        + "data_devolucao, endereco_entrega, valor_total, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = c.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, pedido.getCliente().getId());
                    ps.setObject(2, pedido.getDataPedido());
                    ps.setObject(3, pedido.getDataEntrega());
                    ps.setObject(4, pedido.getDataDevolucao());
                    ps.setString(5, pedido.getEnderecoEntrega());
                    ps.setBigDecimal(6, pedido.getValorTotal());
                    ps.setString(7, pedido.getStatus().name());
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            pedido.setId(rs.getInt(1));
                        }
                    }
                }

                String sqlItem = "INSERT INTO item_pedido (id_pedido, id_item, quantidade, valor_unitario) "
                        + "VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = c.prepareStatement(sqlItem)) {
                    for (ItemPedido ip : pedido.getItens()) {
                        ps.setInt(1, pedido.getId());
                        ps.setInt(2, ip.getItem().getId());
                        ps.setInt(3, ip.getQuantidade());
                        ps.setBigDecimal(4, ip.getValorUnitario());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }

                c.commit();
            } catch (RuntimeException | SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /**
     * Atualiza o status de um pedido. Ao mudar para {@link StatusPedido#DEVOLVIDO}
     * ou {@link StatusPedido#CANCELADO}, devolve os itens ao estoque, na
     * mesma transação.
     *
     * @param idPedido identificador do pedido
     * @param novo     novo status
     * @throws SQLException em caso de erro no banco
     */
    public void atualizarStatus(int idPedido, StatusPedido novo) throws SQLException {
        try (Connection c = ConexaoBD.getConexao()) {
            c.setAutoCommit(false);
            try {
                if (novo.isFinal()) {
                    for (ItemPedido ip : buscarItens(c, idPedido)) {
                        devolverEstoque(c, ip.getItem().getId(), ip.getQuantidade());
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE pedido SET status = ? WHERE id_pedido = ?")) {
                    ps.setString(1, novo.name());
                    ps.setInt(2, idPedido);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (RuntimeException | SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /**
     * Exclui um pedido e devolve os itens ao estoque, na mesma transação.
     * Deve ser chamado apenas para pedidos ainda {@link StatusPedido#AGENDADO}
     * (essa verificação é feita pelo serviço).
     *
     * @param idPedido identificador do pedido
     * @throws SQLException em caso de erro no banco
     */
    public void excluirDevolvendoEstoque(int idPedido) throws SQLException {
        try (Connection c = ConexaoBD.getConexao()) {
            c.setAutoCommit(false);
            try {
                for (ItemPedido ip : buscarItens(c, idPedido)) {
                    devolverEstoque(c, ip.getItem().getId(), ip.getQuantidade());
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "DELETE FROM pedido WHERE id_pedido = ?")) {
                    ps.setInt(1, idPedido);
                    ps.executeUpdate();
                }
                c.commit();
            } catch (RuntimeException | SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /**
     * Busca um pedido com o cliente e os itens já carregados.
     *
     * @param id identificador do pedido
     * @return o pedido, ou {@code null} se não existir
     * @throws SQLException em caso de erro no banco
     */
    public Pedido buscarComItens(int id) throws SQLException {
        try (Connection c = ConexaoBD.getConexao()) {
            Pedido pedido;
            String sql = "SELECT p.*, c.nome, c.telefone, c.endereco AS endereco_cliente, "
                    + "c.observacoes FROM pedido p JOIN cliente c ON c.id_cliente = p.id_cliente "
                    + "WHERE p.id_pedido = ?";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        return null;
                    }
                    pedido = mapearPedido(rs);
                }
            }
            pedido.getItens().addAll(buscarItens(c, id));
            return pedido;
        }
    }

    /**
     * Lista pedidos para a tela de listagem, com o nome do cliente, sem
     * carregar os itens (carregados sob demanda em {@link #buscarComItens}).
     *
     * @param filtroTexto  texto buscado no nome do cliente; vazio ou
     *                     {@code null} não filtra
     * @param filtroStatus status para filtrar; {@code null} lista todos
     * @return pedidos encontrados, do mais recente para o mais antigo
     * @throws SQLException em caso de erro no banco
     */
    public List<Pedido> listarResumo(String filtroTexto, StatusPedido filtroStatus) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT p.*, c.nome, c.telefone, c.endereco AS endereco_cliente, c.observacoes "
                        + "FROM pedido p JOIN cliente c ON c.id_cliente = p.id_cliente WHERE 1 = 1");
        List<Object> parametros = new ArrayList<>();
        if (filtroTexto != null && !filtroTexto.isBlank()) {
            sql.append(" AND c.nome LIKE ?");
            parametros.add("%" + filtroTexto.trim() + "%");
        }
        if (filtroStatus != null) {
            sql.append(" AND p.status = ?");
            parametros.add(filtroStatus.name());
        }
        sql.append(" ORDER BY p.data_entrega DESC, p.id_pedido DESC");

        List<Pedido> pedidos = new ArrayList<>();
        try (Connection c = ConexaoBD.getConexao(); PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    pedidos.add(mapearPedido(rs));
                }
            }
        }
        return pedidos;
    }

    /**
     * Reduz a quantidade disponível de um item, dentro de uma transação já
     * aberta. Usa {@code SELECT ... FOR UPDATE} para travar a linha do item
     * até o fim da transação.
     *
     * @param c          conexão com {@code autoCommit} desligado
     * @param idItem     identificador do item
     * @param quantidade quantidade a baixar
     * @throws SQLException                 em caso de erro no banco
     * @throws EstoqueInsuficienteException se não houver estoque suficiente
     */
    private void baixarEstoque(Connection c, int idItem, int quantidade) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT nome, quantidade_disponivel FROM item WHERE id_item = ? FOR UPDATE")) {
            ps.setInt(1, idItem);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException("Item " + idItem + " não existe mais.");
                }
                String nome = rs.getString("nome");
                int disponivel = rs.getInt("quantidade_disponivel");
                if (disponivel < quantidade) {
                    throw new EstoqueInsuficienteException(nome, disponivel);
                }
            }
        }
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE item SET quantidade_disponivel = quantidade_disponivel - ? WHERE id_item = ?")) {
            ps.setInt(1, quantidade);
            ps.setInt(2, idItem);
            ps.executeUpdate();
        }
    }

    /**
     * Devolve unidades ao estoque de um item, sem passar da quantidade
     * total, dentro de uma transação já aberta.
     *
     * @param c          conexão com {@code autoCommit} desligado
     * @param idItem     identificador do item
     * @param quantidade quantidade a devolver
     * @throws SQLException em caso de erro no banco
     */
    private void devolverEstoque(Connection c, int idItem, int quantidade) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE item SET quantidade_disponivel = LEAST(quantidade_total, quantidade_disponivel + ?) "
                        + "WHERE id_item = ?")) {
            ps.setInt(1, quantidade);
            ps.setInt(2, idItem);
            ps.executeUpdate();
        }
    }

    private List<ItemPedido> buscarItens(Connection c, int idPedido) throws SQLException {
        List<ItemPedido> itens = new ArrayList<>();
        String sql = "SELECT ip.id_item_pedido, ip.quantidade, ip.valor_unitario, i.* "
                + "FROM item_pedido ip JOIN item i ON i.id_item = ip.id_item WHERE ip.id_pedido = ?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Item item = new Item(
                            rs.getInt("id_item"),
                            rs.getString("nome"),
                            rs.getString("descricao"),
                            rs.getString("categoria"),
                            rs.getInt("quantidade_total"),
                            rs.getInt("quantidade_disponivel"),
                            rs.getBigDecimal("valor_diaria"));
                    BigDecimal valorUnitario = rs.getBigDecimal("valor_unitario");
                    itens.add(new ItemPedido(rs.getInt("id_item_pedido"), item,
                            rs.getInt("quantidade"), valorUnitario));
                }
            }
        }
        return itens;
    }

    private Pedido mapearPedido(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente(
                rs.getInt("id_cliente"),
                rs.getString("nome"),
                rs.getString("telefone"),
                rs.getString("endereco_cliente"),
                rs.getString("observacoes"));

        Pedido pedido = new Pedido();
        pedido.setId(rs.getInt("id_pedido"));
        pedido.setCliente(cliente);
        pedido.setDataPedido(rs.getObject("data_pedido", java.time.LocalDate.class));
        pedido.setDataEntrega(rs.getObject("data_entrega", java.time.LocalDate.class));
        pedido.setDataDevolucao(rs.getObject("data_devolucao", java.time.LocalDate.class));
        pedido.setEnderecoEntrega(rs.getString("endereco_entrega"));
        pedido.setValorTotal(rs.getBigDecimal("valor_total"));
        pedido.setStatus(StatusPedido.valueOf(rs.getString("status")));
        return pedido;
    }
}
