package br.com.festaecia.model;

/**
 * Cliente da locadora. É quem realiza os pedidos de locação.
 */
public class Cliente {

    private int id;
    private String nome;
    private String telefone;
    private String endereco;
    private String observacoes;

    /** Cria um cliente vazio (usado ao ler do banco ou do formulário). */
    public Cliente() {
    }

    /**
     * Cria um cliente completo.
     *
     * @param id          identificador (0 se ainda não foi gravado)
     * @param nome        nome do cliente
     * @param telefone    telefone para contato
     * @param endereco    endereço (usado como sugestão de entrega)
     * @param observacoes observações livres sobre o cliente
     */
    public Cliente(int id, String nome, String telefone, String endereco, String observacoes) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.endereco = endereco;
        this.observacoes = observacoes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    /**
     * Texto usado em listas de seleção (combo de clientes no pedido).
     *
     * @return nome e telefone do cliente
     */
    @Override
    public String toString() {
        return nome + " - " + telefone;
    }
}
