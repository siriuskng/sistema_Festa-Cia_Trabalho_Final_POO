package br.com.festaecia.controller;

import br.com.festaecia.model.Cliente;
import br.com.festaecia.model.Item;
import br.com.festaecia.model.ItemPedido;
import br.com.festaecia.model.Pedido;
import br.com.festaecia.model.StatusPedido;
import br.com.festaecia.service.ClienteService;
import br.com.festaecia.service.ItemService;
import br.com.festaecia.service.PedidoService;
import br.com.festaecia.service.RegraNegocioException;
import br.com.festaecia.util.Mensagens;
import br.com.festaecia.util.Navegador;
import br.com.festaecia.util.FormatoData;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Controlador da tela de pedidos: lista e filtra pedidos, registra novos
 * pedidos com seus itens e controla a mudança de status (entrega,
 * devolução e cancelamento), incluindo a baixa e a devolução automática
 * de estoque.
 */
public class PedidoController {

    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    private final PedidoService pedidoService = new PedidoService();
    private final ClienteService clienteService = new ClienteService();
    private final ItemService itemService = new ItemService();

    private final ObservableList<Pedido> pedidos = FXCollections.observableArrayList();
    private final ObservableList<ItemPedido> itensDoFormulario = FXCollections.observableArrayList();

    /** Pedido selecionado na lista; {@code null} quando é um pedido novo (ainda não salvo). */
    private Pedido emEdicao;

    @FXML private TextField txtBusca;
    @FXML private ComboBox<String> cmbFiltroStatus;
    @FXML private TableView<Pedido> tabela;
    @FXML private TableColumn<Pedido, Number> colNumero;
    @FXML private TableColumn<Pedido, String> colCliente;
    @FXML private TableColumn<Pedido, String> colEntrega;
    @FXML private TableColumn<Pedido, String> colDevolucao;
    @FXML private TableColumn<Pedido, String> colStatus;
    @FXML private TableColumn<Pedido, String> colValorTotal;

    @FXML private Label lblModo;
    @FXML private Label lblStatusAtual;
    @FXML private ComboBox<Cliente> cmbCliente;
    @FXML private DatePicker dpEntrega;
    @FXML private DatePicker dpDevolucao;
    @FXML private TextField txtEndereco;

    @FXML private ComboBox<Item> cmbItem;
    @FXML private TextField txtQuantidadeItem;
    @FXML private TableView<ItemPedido> tabelaItens;
    @FXML private TableColumn<ItemPedido, String> colItemNome;
    @FXML private TableColumn<ItemPedido, Number> colItemQuantidade;
    @FXML private TableColumn<ItemPedido, String> colItemValor;
    @FXML private TableColumn<ItemPedido, String> colItemSubtotal;
    @FXML private Label lblTotal;

    @FXML private Button btnAdicionarItem;
    @FXML private Button btnRemoverItem;
    @FXML private Button btnSalvar;
    @FXML private Button btnEntregar;
    @FXML private Button btnDevolver;
    @FXML private Button btnCancelar;
    @FXML private Button btnExcluir;

    /** Executado pelo JavaFX ao carregar a tela. */
    @FXML
    private void initialize() {
        configurarTabelaPedidos();
        configurarTabelaItens();
        FormatoData.aplicarEm(dpEntrega);
        FormatoData.aplicarEm(dpDevolucao);
        dpEntrega.valueProperty().addListener((obs, antigo, novo) -> atualizarTotalExibido());
        dpDevolucao.valueProperty().addListener((obs, antigo, novo) -> atualizarTotalExibido());

        cmbFiltroStatus.setItems(FXCollections.observableArrayList(
                "Todos", "Agendado", "Entregue", "Devolvido", "Cancelado"));
        cmbFiltroStatus.setValue("Todos");
        cmbFiltroStatus.valueProperty().addListener((obs, antigo, novo) -> carregarLista());
        txtBusca.textProperty().addListener((obs, antigo, novo) -> carregarLista());

        tabela.getSelectionModel().selectedItemProperty().addListener((obs, antigo, selecionado) -> {
            if (selecionado != null) {
                abrirPedido(selecionado.getId());
            }
        });

        cmbCliente.valueProperty().addListener((obs, antigo, novo) -> {
            if (novo != null && (txtEndereco.getText() == null || txtEndereco.getText().isBlank())) {
                txtEndereco.setText(novo.getEndereco() == null ? "" : novo.getEndereco());
            }
        });

        carregarLista();
        carregarCombos();
        novo();
    }

    @FXML
    private void novo() {
        emEdicao = null;
        tabela.getSelectionModel().clearSelection();
        cmbCliente.setValue(null);
        dpEntrega.setValue(null);
        dpDevolucao.setValue(null);
        txtEndereco.clear();
        itensDoFormulario.clear();
        txtQuantidadeItem.clear();
        cmbItem.setValue(null);
        lblModo.setText("Novo pedido");
        lblStatusAtual.setText("");
        atualizarTotalExibido();
        definirModoEdicao(true);
    }

    @FXML
    private void adicionarItem() {
        Item item = cmbItem.getValue();
        if (item == null) {
            Mensagens.erro("Selecione um item para adicionar.");
            return;
        }
        int quantidade;
        try {
            quantidade = Integer.parseInt(txtQuantidadeItem.getText().trim());
        } catch (NumberFormatException e) {
            Mensagens.erro("Informe a quantidade usando apenas números inteiros, por exemplo: 10.");
            return;
        }
        if (quantidade <= 0) {
            Mensagens.erro("A quantidade deve ser maior que zero.");
            return;
        }
        boolean jaAdicionado = itensDoFormulario.stream().anyMatch(ip -> ip.getItem().getId() == item.getId());
        if (jaAdicionado) {
            Mensagens.erro("Este item já foi adicionado. Remova-o antes de adicionar novamente.");
            return;
        }
        if (quantidade > item.getQuantidadeDisponivel()) {
            Mensagens.erro("Estoque insuficiente de " + item.getNome()
                    + ": restam apenas " + item.getQuantidadeDisponivel() + ".");
            return;
        }
        itensDoFormulario.add(new ItemPedido(0, item, quantidade, item.getValorDiaria()));
        cmbItem.setValue(null);
        txtQuantidadeItem.clear();
        atualizarTotalExibido();
    }

    @FXML
    private void removerItem() {
        ItemPedido selecionado = tabelaItens.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            Mensagens.erro("Selecione, na tabela de itens do pedido, qual item deseja remover.");
            return;
        }
        itensDoFormulario.remove(selecionado);
        atualizarTotalExibido();
    }

    @FXML
    private void salvar() {
        Pedido pedido = new Pedido();
        pedido.setCliente(cmbCliente.getValue());
        pedido.setDataEntrega(dpEntrega.getValue());
        pedido.setDataDevolucao(dpDevolucao.getValue());
        pedido.setEnderecoEntrega(txtEndereco.getText() == null ? "" : txtEndereco.getText().trim());
        for (ItemPedido ip : itensDoFormulario) {
            pedido.adicionarItem(ip.getItem(), ip.getQuantidade(), ip.getValorUnitario());
        }
        try {
            pedidoService.registrar(pedido);
            Mensagens.sucesso("Pedido nº " + pedido.getId() + " registrado com sucesso.");
            carregarLista();
            carregarCombos();
            novo();
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void marcarEntregue() {
        mudarStatus(StatusPedido.ENTREGUE, "Pedido marcado como entregue.");
    }

    @FXML
    private void marcarDevolvido() {
        mudarStatus(StatusPedido.DEVOLVIDO, "Devolução registrada. Os itens voltaram ao estoque.");
    }

    @FXML
    private void cancelar() {
        if (!Mensagens.confirmar("Deseja realmente cancelar este pedido? Os itens voltarão ao estoque.")) {
            return;
        }
        mudarStatus(StatusPedido.CANCELADO, "Pedido cancelado. Os itens voltaram ao estoque.");
    }

    @FXML
    private void excluir() {
        if (emEdicao == null) {
            return;
        }
        if (!Mensagens.confirmar("Deseja realmente excluir o pedido nº " + emEdicao.getId() + "?")) {
            return;
        }
        try {
            pedidoService.excluir(emEdicao.getId());
            Mensagens.sucesso("Pedido excluído com sucesso.");
            carregarLista();
            carregarCombos();
            novo();
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void voltar() {
        Navegador.irPara("menu-principal.fxml", "Festa e Cia");
    }

    private void mudarStatus(StatusPedido novo, String mensagemSucesso) {
        if (emEdicao == null) {
            return;
        }
        try {
            pedidoService.mudarStatus(emEdicao.getId(), novo);
            Mensagens.sucesso(mensagemSucesso);
            carregarLista();
            carregarCombos();
            abrirPedido(emEdicao.getId());
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    private void abrirPedido(int id) {
        try {
            Pedido pedido = pedidoService.buscarComItens(id);
            if (pedido == null) {
                Mensagens.erro("Este pedido não existe mais. Atualize a lista.");
                carregarLista();
                return;
            }
            emEdicao = pedido;
            lblModo.setText("Pedido nº " + pedido.getId());
            lblStatusAtual.setText("Situação atual: " + pedido.getStatus());
            cmbCliente.setValue(pedido.getCliente());
            dpEntrega.setValue(pedido.getDataEntrega());
            dpDevolucao.setValue(pedido.getDataDevolucao());
            txtEndereco.setText(pedido.getEnderecoEntrega());
            itensDoFormulario.setAll(pedido.getItens());
            lblTotal.setText("Total: " + formatarMoeda(pedido.getValorTotal()));
            definirModoEdicao(false);
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    /**
     * Ajusta quais campos e botões ficam habilitados: um pedido novo pode
     * ser editado livremente; um pedido já salvo só permite mudar o
     * status, para preservar o histórico do que foi realmente locado.
     *
     * @param criandoNovo {@code true} para um pedido ainda não salvo
     */
    private void definirModoEdicao(boolean criandoNovo) {
        cmbCliente.setDisable(!criandoNovo);
        dpEntrega.setDisable(!criandoNovo);
        dpDevolucao.setDisable(!criandoNovo);
        txtEndereco.setDisable(!criandoNovo);
        cmbItem.setDisable(!criandoNovo);
        txtQuantidadeItem.setDisable(!criandoNovo);
        btnAdicionarItem.setDisable(!criandoNovo);
        btnRemoverItem.setDisable(!criandoNovo);
        btnSalvar.setDisable(!criandoNovo);

        StatusPedido status = criandoNovo ? null : emEdicao.getStatus();
        btnEntregar.setDisable(status != StatusPedido.AGENDADO);
        btnCancelar.setDisable(status != StatusPedido.AGENDADO);
        btnDevolver.setDisable(status != StatusPedido.ENTREGUE);
        btnExcluir.setDisable(status != StatusPedido.AGENDADO);
    }

    private void carregarLista() {
        try {
            String status = cmbFiltroStatus.getValue();
            StatusPedido filtro = (status == null || status.equals("Todos"))
                    ? null : StatusPedido.valueOf(status.toUpperCase(BR));
            pedidos.setAll(pedidoService.listar(txtBusca.getText(), filtro));
            tabela.setItems(pedidos);
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    private void carregarCombos() {
        try {
            cmbCliente.setItems(FXCollections.observableArrayList(clienteService.listar()));
            List<Item> disponiveis = itemService.listar().stream()
                    .filter(i -> i.getQuantidadeDisponivel() > 0)
                    .toList();
            cmbItem.setItems(FXCollections.observableArrayList(disponiveis));
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    private void atualizarTotalExibido() {
        BigDecimal somaItens = itensDoFormulario.stream()
                .map(ItemPedido::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        long dias = 1;
        if (dpEntrega.getValue() != null && dpDevolucao.getValue() != null
                && !dpDevolucao.getValue().isBefore(dpEntrega.getValue())) {
            dias = Math.max(1, java.time.temporal.ChronoUnit.DAYS.between(dpEntrega.getValue(), dpDevolucao.getValue()));
        }
        lblTotal.setText("Total: " + formatarMoeda(somaItens.multiply(BigDecimal.valueOf(dias)))
                + "  (" + dias + (dias == 1 ? " dia)" : " dias)"));
    }

    private void configurarTabelaPedidos() {
        colNumero.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().getId()));
        colCliente.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getCliente().getNome()));
        colEntrega.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarData(c.getValue().getDataEntrega())));
        colDevolucao.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarData(c.getValue().getDataDevolucao())));
        colStatus.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getStatus().toString()));
        colValorTotal.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarMoeda(c.getValue().getValorTotal())));
        tabela.setPlaceholder(new Label("Nenhum pedido encontrado."));
    }

    private void configurarTabelaItens() {
        colItemNome.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getItem().getNome()));
        colItemQuantidade.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().getQuantidade()));
        colItemValor.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarMoeda(c.getValue().getValorUnitario())));
        colItemSubtotal.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarMoeda(c.getValue().getSubtotal())));
        tabelaItens.setItems(itensDoFormulario);
        tabelaItens.setPlaceholder(new Label("Nenhum item adicionado."));
    }


    private String formatarData(LocalDate data) {
        return FormatoData.formatar(data);
    }

    private String formatarMoeda(BigDecimal valor) {
        return String.format(BR, "R$ %.2f", valor);
    }
}
