package br.com.festaecia.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.DatePicker;
import javafx.util.StringConverter;

/**
 * Formato de data usado em todas as telas do sistema (dd/mm/aaaa), para
 * manter a exibição e a digitação consistentes nos campos de data.
 */
public final class FormatoData {

    /** Padrão de exibição e digitação de datas: dd/mm/aaaa. */
    public static final DateTimeFormatter PADRAO = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private FormatoData() {
    }

    /**
     * Configura um seletor de data para exibir e aceitar o formato
     * dd/mm/aaaa, independente do idioma do sistema operacional.
     *
     * @param seletor campo de data a configurar
     */
    public static void aplicarEm(DatePicker seletor) {
        seletor.setPromptText("dd/mm/aaaa");
        seletor.setConverter(new StringConverter<>() {
            @Override
            public String toString(LocalDate data) {
                return data == null ? "" : PADRAO.format(data);
            }

            @Override
            public LocalDate fromString(String texto) {
                return (texto == null || texto.isBlank()) ? null : LocalDate.parse(texto, PADRAO);
            }
        });
    }

    /**
     * Formata uma data no padrão dd/mm/aaaa.
     *
     * @param data data a formatar, pode ser {@code null}
     * @return texto formatado, ou vazio se a data for {@code null}
     */
    public static String formatar(LocalDate data) {
        return data == null ? "" : PADRAO.format(data);
    }
}
