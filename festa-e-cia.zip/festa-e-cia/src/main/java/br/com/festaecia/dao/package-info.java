/**
 * Acesso ao banco de dados: uma classe DAO por entidade, usando JDBC.
 */
package br.com.festaecia.dao;
