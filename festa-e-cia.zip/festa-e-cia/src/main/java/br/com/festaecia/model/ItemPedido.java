package br.com.festaecia.model;

import java.math.BigDecimal;

/**
 * Um item, com a quantidade e o valor da diária combinados, dentro de um
 * pedido de locação. O valor é gravado no momento do pedido, para não
 * mudar se o preço do item mudar depois.
 */
public class ItemPedido {

    private int id;
    private Item item;
    private int quantidade;
    private BigDecimal valorUnitario;

    /** Cria um item de pedido vazio. */
    public ItemPedido() {
    }

    /**
     * Cria um item de pedido completo.
     *
     * @param id            identificador (0 se ainda não foi gravado)
     * @param item          item locado
     * @param quantidade    quantidade locada
     * @param valorUnitario valor da diária combinado para este pedido
     */
    public ItemPedido(int id, Item item, int quantidade, BigDecimal valorUnitario) {
        this.id = id;
        this.item = item;
        this.quantidade = quantidade;
        this.valorUnitario = valorUnitario;
    }

    /**
     * Subtotal deste item, sem considerar os dias de locação.
     *
     * @return quantidade vezes o valor unitário
     */
    public BigDecimal getSubtotal() {
        return valorUnitario.multiply(BigDecimal.valueOf(quantidade));
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public BigDecimal getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(BigDecimal valorUnitario) {
        this.valorUnitario = valorUnitario;
    }
}
