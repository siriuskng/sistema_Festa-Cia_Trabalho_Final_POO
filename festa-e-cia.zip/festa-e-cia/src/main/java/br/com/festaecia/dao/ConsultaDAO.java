package br.com.festaecia.dao;

import br.com.festaecia.model.EntregaResumo;
import br.com.festaecia.model.ItemMaisAlugado;
import br.com.festaecia.model.StatusPedido;
import br.com.festaecia.util.ConexaoBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Consultas que combinam várias tabelas para produzir informações prontas
 * para a tela e para os relatórios JasperReports: entregas de um período
 * e o ranking de itens mais alugados.
 */
public class ConsultaDAO {

    /**
     * Lista as entregas (pedidos ainda agendados ou já entregues) cuja
     * data de entrega cai dentro do período informado, com o cliente e um
     * resumo dos itens de cada pedido.
     *
     * @param inicio data inicial do período (inclusiva)
     * @param fim    data final do período (inclusiva)
     * @return entregas do período, da mais próxima para a mais distante
     * @throws SQLException em caso de erro no banco
     */
    public List<EntregaResumo> listarEntregasNoPeriodo(LocalDate inicio, LocalDate fim) throws SQLException {
        String sql = "SELECT p.id_pedido, c.nome, c.telefone, p.data_entrega, p.data_devolucao, "
                + "p.endereco_entrega, p.status, p.valor_total, "
                + "GROUP_CONCAT(CONCAT(ip.quantidade, 'x ', i.nome) ORDER BY i.nome SEPARATOR ', ') AS itens_resumo "
                + "FROM pedido p "
                + "JOIN cliente c ON c.id_cliente = p.id_cliente "
                + "JOIN item_pedido ip ON ip.id_pedido = p.id_pedido "
                + "JOIN item i ON i.id_item = ip.id_item "
                + "WHERE p.data_entrega BETWEEN ? AND ? AND p.status IN ('AGENDADO', 'ENTREGUE') "
                + "GROUP BY p.id_pedido "
                + "ORDER BY p.data_entrega, p.id_pedido";
        List<EntregaResumo> entregas = new ArrayList<>();
        try (Connection c = ConexaoBD.getConexao(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, inicio);
            ps.setObject(2, fim);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    entregas.add(new EntregaResumo(
                            rs.getInt("id_pedido"),
                            rs.getString("nome"),
                            rs.getString("telefone"),
                            rs.getObject("data_entrega", LocalDate.class),
                            rs.getObject("data_devolucao", LocalDate.class),
                            rs.getString("endereco_entrega"),
                            StatusPedido.valueOf(rs.getString("status")),
                            rs.getString("itens_resumo"),
                            rs.getBigDecimal("valor_total")));
                }
            }
        }
        return entregas;
    }

    /**
     * Soma, por item, as quantidades locadas em pedidos cuja data de
     * entrega cai dentro do período informado (ignorando pedidos
     * cancelados), do mais locado para o menos locado.
     *
     * @param inicio data inicial do período (inclusiva)
     * @param fim    data final do período (inclusiva)
     * @return itens mais alugados no período
     * @throws SQLException em caso de erro no banco
     */
    public List<ItemMaisAlugado> listarItensMaisAlugados(LocalDate inicio, LocalDate fim) throws SQLException {
        String sql = "SELECT i.nome, i.categoria, SUM(ip.quantidade) AS quantidade, "
                + "COUNT(DISTINCT p.id_pedido) AS pedidos "
                + "FROM item_pedido ip "
                + "JOIN pedido p ON p.id_pedido = ip.id_pedido "
                + "JOIN item i ON i.id_item = ip.id_item "
                + "WHERE p.data_entrega BETWEEN ? AND ? AND p.status <> 'CANCELADO' "
                + "GROUP BY i.id_item "
                + "ORDER BY quantidade DESC, i.nome";
        List<ItemMaisAlugado> itens = new ArrayList<>();
        try (Connection c = ConexaoBD.getConexao(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, inicio);
            ps.setObject(2, fim);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    itens.add(new ItemMaisAlugado(
                            rs.getString("nome"),
                            rs.getString("categoria"),
                            rs.getInt("quantidade"),
                            rs.getInt("pedidos")));
                }
            }
        }
        return itens;
    }
}
