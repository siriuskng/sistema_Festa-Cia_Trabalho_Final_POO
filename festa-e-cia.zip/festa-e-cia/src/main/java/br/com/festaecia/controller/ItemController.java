package br.com.festaecia.controller;

import br.com.festaecia.model.Item;
import br.com.festaecia.service.ItemService;
import br.com.festaecia.service.RegraNegocioException;
import br.com.festaecia.util.Mensagens;
import br.com.festaecia.util.Navegador;
import java.math.BigDecimal;
import java.util.Locale;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Controlador da tela de estoque: lista os itens, permite buscar e fazer
 * o cadastro, a alteração e a exclusão em uma única tela.
 */
public class ItemController {

    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    private final ItemService service = new ItemService();
    private final ObservableList<Item> itens = FXCollections.observableArrayList();
    private FilteredList<Item> filtrados;
    /** Item selecionado para alteração; {@code null} quando é um cadastro novo. */
    private Item emEdicao;

    @FXML private TextField txtBusca;
    @FXML private TextField txtNome;
    @FXML private TextField txtDescricao;
    @FXML private TextField txtQuantidade;
    @FXML private TextField txtValor;
    @FXML private ComboBox<String> cmbCategoria;
    @FXML private Label lblModo;
    @FXML private Label lblDisponivel;
    @FXML private Button btnExcluir;
    @FXML private TableView<Item> tabela;
    @FXML private TableColumn<Item, String> colNome;
    @FXML private TableColumn<Item, String> colCategoria;
    @FXML private TableColumn<Item, Integer> colTotal;
    @FXML private TableColumn<Item, Integer> colDisponivel;
    @FXML private TableColumn<Item, String> colValor;

    /** Executado pelo JavaFX ao carregar a tela. */
    @FXML
    private void initialize() {
        colNome.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getNome()));
        colCategoria.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getCategoria()));
        colTotal.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().getQuantidadeTotal()));
        colDisponivel.setCellValueFactory(c -> new ReadOnlyObjectWrapper<>(c.getValue().getQuantidadeDisponivel()));
        colValor.setCellValueFactory(c -> new ReadOnlyStringWrapper(formatarMoeda(c.getValue().getValorDiaria())));

        filtrados = new FilteredList<>(itens, i -> true);
        SortedList<Item> ordenados = new SortedList<>(filtrados);
        ordenados.comparatorProperty().bind(tabela.comparatorProperty());
        tabela.setItems(ordenados);
        tabela.setPlaceholder(new Label("Nenhum item encontrado."));

        txtBusca.textProperty().addListener((obs, antigo, novo) -> filtrar(novo));
        tabela.getSelectionModel().selectedItemProperty().addListener((obs, antigo, selecionado) -> {
            if (selecionado != null) {
                editar(selecionado);
            }
        });

        carregar();
        novo();
    }

    @FXML
    private void novo() {
        emEdicao = null;
        tabela.getSelectionModel().clearSelection();
        txtNome.clear();
        txtDescricao.clear();
        cmbCategoria.setValue(null);
        cmbCategoria.getEditor().clear();
        txtQuantidade.clear();
        txtValor.clear();
        lblModo.setText("Novo item");
        lblDisponivel.setText("O disponível começa igual à quantidade total.");
        btnExcluir.setDisable(true);
        txtNome.requestFocus();
    }

    @FXML
    private void salvar() {
        Item item = lerFormulario();
        if (item == null) {
            return;
        }
        try {
            service.salvar(item);
            Mensagens.sucesso("Item salvo com sucesso.");
            carregar();
            novo();
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void excluir() {
        if (emEdicao == null) {
            return;
        }
        if (!Mensagens.confirmar("Deseja realmente excluir o item \"" + emEdicao.getNome() + "\"?")) {
            return;
        }
        try {
            service.excluir(emEdicao.getId());
            Mensagens.sucesso("Item excluído com sucesso.");
            carregar();
            novo();
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    @FXML
    private void voltar() {
        Navegador.irPara("menu-principal.fxml", "Festa e Cia");
    }

    private void editar(Item item) {
        emEdicao = item;
        txtNome.setText(item.getNome());
        txtDescricao.setText(item.getDescricao() == null ? "" : item.getDescricao());
        cmbCategoria.setValue(item.getCategoria());
        txtQuantidade.setText(String.valueOf(item.getQuantidadeTotal()));
        txtValor.setText(String.format(BR, "%.2f", item.getValorDiaria()));
        lblModo.setText("Alterar item");
        lblDisponivel.setText("Disponível agora: " + item.getQuantidadeDisponivel()
                + " (alugados: " + item.getQuantidadeAlugada() + ")");
        btnExcluir.setDisable(false);
    }

    private void carregar() {
        try {
            itens.setAll(service.listar());
            cmbCategoria.setItems(FXCollections.observableArrayList(service.listarCategorias()));
        } catch (RegraNegocioException e) {
            Mensagens.erro(e.getMessage());
        }
    }

    private void filtrar(String texto) {
        String busca = texto == null ? "" : texto.trim().toLowerCase(BR);
        filtrados.setPredicate(i -> busca.isEmpty()
                || i.getNome().toLowerCase(BR).contains(busca)
                || i.getCategoria().toLowerCase(BR).contains(busca));
    }

    /** Lê o formulário. Retorna {@code null} (após avisar o usuário) se houver número inválido. */
    private Item lerFormulario() {
        int quantidade;
        BigDecimal valor;
        try {
            quantidade = Integer.parseInt(txtQuantidade.getText().trim());
        } catch (NumberFormatException e) {
            Mensagens.erro("Informe a quantidade total usando apenas números inteiros, por exemplo: 50.");
            txtQuantidade.requestFocus();
            return null;
        }
        try {
            valor = new BigDecimal(txtValor.getText().trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            Mensagens.erro("Informe o valor da diária usando números, por exemplo: 2,50.");
            txtValor.requestFocus();
            return null;
        }
        Item item = new Item();
        item.setId(emEdicao == null ? 0 : emEdicao.getId());
        item.setNome(txtNome.getText().trim());
        item.setDescricao(txtDescricao.getText().trim());
        item.setCategoria(cmbCategoria.getEditor().getText().trim());
        item.setQuantidadeTotal(quantidade);
        item.setValorDiaria(valor);
        return item;
    }

    private String formatarMoeda(BigDecimal valor) {
        return String.format(BR, "R$ %.2f", valor);
    }
}
