@echo off
REM Gera o instalador do Festa e Cia (Windows).
REM Pre-requisitos: JDK 17+ com jpackage (vem junto do JDK) e Maven.

echo 1/2 - Compilando o projeto e juntando as dependencias (JavaFX, MySQL, JasperReports)...
call mvn clean package
if errorlevel 1 (
    echo.
    echo ERRO ao compilar o projeto. Veja as mensagens acima.
    pause
    exit /b 1
)

echo 2/2 - Gerando o instalador com jpackage...
if exist instalador rmdir /s /q instalador

jpackage ^
  --input target ^
  --name "Festa e Cia" ^
  --main-jar festa-e-cia-completo.jar ^
  --main-class br.com.festaecia.Launcher ^
  --type app-image ^
  --app-version 1.0.0 ^
  --vendor "Festa e Cia" ^
  --dest instalador

if errorlevel 1 (
    echo.
    echo ERRO ao gerar o instalador. Veja as mensagens acima.
    pause
    exit /b 1
)

echo.
echo Pronto! O programa esta na pasta: instalador\Festa e Cia
echo Para distribuir, copie essa pasta inteira para o outro computador - ela ja inclui o Java.
echo.
echo Se o seu computador tiver o WiX Toolset instalado, voce pode trocar --type app-image
echo por --type msi (ou --type exe) para gerar um instalador de verdade, com atalho e
echo desinstalador. O WiX e baixado em https://wixtoolset.org/
pause
