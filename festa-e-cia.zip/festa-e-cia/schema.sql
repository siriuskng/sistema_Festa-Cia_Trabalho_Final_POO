-- =====================================================================
-- Festa e Cia - Script de criação do banco de dados (MySQL 8.0.16+)
-- Como executar:
--   mysql -u root -p < schema.sql
-- ou abra este arquivo no MySQL Workbench e execute tudo.
-- ATENÇÃO: para recriar do zero, descomente a linha DROP DATABASE abaixo.
-- =====================================================================

-- DROP DATABASE IF EXISTS festa_e_cia;

-- Garante que acentos sejam gravados corretamente, independente do cliente usado.
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS festa_e_cia
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE festa_e_cia;

-- ---------------------------------------------------------------------
-- CLIENTE
-- ---------------------------------------------------------------------
CREATE TABLE cliente (
    id_cliente   INT          NOT NULL AUTO_INCREMENT,
    nome         VARCHAR(100) NOT NULL,
    telefone     VARCHAR(20)  NOT NULL,
    endereco     VARCHAR(200),
    observacoes  TEXT,
    CONSTRAINT pk_cliente PRIMARY KEY (id_cliente)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ITEM (inventário)
-- ---------------------------------------------------------------------
CREATE TABLE item (
    id_item               INT           NOT NULL AUTO_INCREMENT,
    nome                  VARCHAR(100)  NOT NULL,
    descricao             VARCHAR(200),
    categoria             VARCHAR(50)   NOT NULL,
    quantidade_total      INT           NOT NULL,
    quantidade_disponivel INT           NOT NULL,
    valor_diaria          DECIMAL(10,2) NOT NULL,
    CONSTRAINT pk_item PRIMARY KEY (id_item),
    CONSTRAINT ck_item_total CHECK (quantidade_total >= 0),
    CONSTRAINT ck_item_disponivel CHECK (quantidade_disponivel >= 0
                                         AND quantidade_disponivel <= quantidade_total),
    CONSTRAINT ck_item_valor CHECK (valor_diaria >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- PEDIDO
-- ---------------------------------------------------------------------
CREATE TABLE pedido (
    id_pedido        INT           NOT NULL AUTO_INCREMENT,
    id_cliente       INT           NOT NULL,
    data_pedido      DATE          NOT NULL,
    data_entrega     DATE          NOT NULL,
    data_devolucao   DATE          NOT NULL,
    endereco_entrega VARCHAR(200)  NOT NULL,
    valor_total      DECIMAL(10,2) NOT NULL DEFAULT 0,
    status           VARCHAR(20)   NOT NULL DEFAULT 'AGENDADO',
    CONSTRAINT pk_pedido PRIMARY KEY (id_pedido),
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (id_cliente)
        REFERENCES cliente (id_cliente)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT ck_pedido_status CHECK (status IN ('AGENDADO', 'ENTREGUE', 'DEVOLVIDO', 'CANCELADO')),
    CONSTRAINT ck_pedido_datas CHECK (data_devolucao >= data_entrega),
    CONSTRAINT ck_pedido_valor CHECK (valor_total >= 0),
    INDEX idx_pedido_data_entrega (data_entrega),
    INDEX idx_pedido_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ITEM_PEDIDO (itens de cada pedido)
-- ---------------------------------------------------------------------
CREATE TABLE item_pedido (
    id_item_pedido INT           NOT NULL AUTO_INCREMENT,
    id_pedido      INT           NOT NULL,
    id_item        INT           NOT NULL,
    quantidade     INT           NOT NULL,
    valor_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT pk_item_pedido PRIMARY KEY (id_item_pedido),
    CONSTRAINT fk_ip_pedido FOREIGN KEY (id_pedido)
        REFERENCES pedido (id_pedido)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ip_item FOREIGN KEY (id_item)
        REFERENCES item (id_item)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT uq_ip_pedido_item UNIQUE (id_pedido, id_item),
    CONSTRAINT ck_ip_quantidade CHECK (quantidade > 0),
    CONSTRAINT ck_ip_valor CHECK (valor_unitario >= 0)
) ENGINE=InnoDB;

-- =====================================================================
-- DADOS DE EXEMPLO
-- O estoque disponível já considera os pedidos AGENDADO e ENTREGUE
-- (itens de pedidos DEVOLVIDO ou CANCELADO voltam ao estoque).
-- =====================================================================
INSERT INTO cliente (nome, telefone, endereco, observacoes) VALUES
('Maria Souza',   '(62) 99111-2233', 'Rua das Flores, 120 - Centro',    'Prefere contato por telefone'),
('João Pereira',  '(62) 98222-3344', 'Av. Brasil, 450 - Setor Sul',     NULL),
('Ana Lima',      '(62) 99333-4455', 'Rua 7, Quadra 12, Lote 3',        'Cliente frequente');

INSERT INTO item (nome, descricao, categoria, quantidade_total, quantidade_disponivel, valor_diaria) VALUES
('Cadeira plástica branca',   'Cadeira empilhável',           'Cadeiras',          100,  60,  2.50),
('Mesa retangular',           'Mesa para 8 lugares',          'Mesas',              20,  15, 15.00),
('Toalha de mesa branca',     'Toalha para mesa retangular',  'Toalhas',            40,  30,  5.00),
('Arranjo de flores',         'Arranjo artificial de centro', 'Decoração',          15,  11,  8.00),
('Jogo de pratos',            'Jogo com 12 peças',            'Louças',             30,  30, 12.00),
('Caixa de som',              'Caixa amplificada 500W',       'Som e iluminação',    5,   4, 60.00);

-- Pedido 1: AGENDADO (2 dias) -> (40*2,50 + 5*15,00) * 2 = 350,00
INSERT INTO pedido (id_cliente, data_pedido, data_entrega, data_devolucao, endereco_entrega, valor_total, status) VALUES
(1, '2026-11-14', '2026-11-20', '2026-11-22', 'Rua das Flores, 120 - Centro', 350.00, 'AGENDADO');
INSERT INTO item_pedido (id_pedido, id_item, quantidade, valor_unitario) VALUES
(1, 1, 40, 2.50),
(1, 2,  5, 15.00);

-- Pedido 2: ENTREGUE (2 dias) -> (10*5,00 + 4*8,00 + 1*60,00) * 2 = 284,00
INSERT INTO pedido (id_cliente, data_pedido, data_entrega, data_devolucao, endereco_entrega, valor_total, status) VALUES
(2, '2026-11-12', '2026-11-15', '2026-11-17', 'Av. Brasil, 450 - Setor Sul', 284.00, 'ENTREGUE');
INSERT INTO item_pedido (id_pedido, id_item, quantidade, valor_unitario) VALUES
(2, 3, 10,  5.00),
(2, 4,  4,  8.00),
(2, 6,  1, 60.00);

-- Pedido 3: DEVOLVIDO (1 dia) -> 24*12,00 = 288,00 (estoque já devolvido)
INSERT INTO pedido (id_cliente, data_pedido, data_entrega, data_devolucao, endereco_entrega, valor_total, status) VALUES
(3, '2026-11-01', '2026-11-07', '2026-11-08', 'Rua 7, Quadra 12, Lote 3', 288.00, 'DEVOLVIDO');
INSERT INTO item_pedido (id_pedido, id_item, quantidade, valor_unitario) VALUES
(3, 5, 24, 12.00);

-- Conferência rápida (opcional):
-- SELECT p.id_pedido, c.nome, p.data_entrega, p.status, p.valor_total
--   FROM pedido p JOIN cliente c ON c.id_cliente = p.id_cliente;
